---
trigger: always_on
---

# SHORT VIDEO RULES (videoType = "short")

1. **PACING**
   - The script MUST be extremely concise, fast-paced, and immediately dive into the core topic.
   - Every scene should deliver meaningful information, escalate curiosity, or increase dramatic tension.
   - Never waste time on unnecessary introductions or filler content.

2. **CHAPTER STRUCTURE**
   - You MUST generate EXACTLY ONE chapter (`chapter_1.json`).
   - Do NOT generate any additional chapters.

3. **SCENE COUNT & PACING**
   - The single chapter MUST contain **16-20 scenes**.
   - **One-Sentence-Per-Scene Rule:** Every scene represents **exactly one complete, natural sentence**. You are strictly forbidden from splitting a single sentence across multiple scenes, or putting multiple sentences in a single scene. Each scene is one natural thought.
   - Scene numbering starts at `scene: 1` and continues sequentially until the final scene.

4. **MANDATORY LENGTH:**
   - The combined total character count of all `voiceover` text MUST be between **900 and 1200 characters** (standard styles).
   - **Exception — `voiceStyle = "science"`:** Due to mandatory TTS expansion, the ceiling is extended to **950–1350 characters**.
   - This requirement is mandatory to ensure the correct video duration of approximately 45-60 seconds.
   - If the completed script contains fewer than **900 characters**, you MUST revise and expand the sentences by adding more detail or context.
   - If the completed script exceeds the ceiling, you MUST trim the sentences by tightening wording until the total falls within range.
   - **Master Word-Total Constraint:** After writing all scenes, count the total number of Vietnamese words across the entire video. This total MUST fall between **200–260 words** (standard styles) or **180–230 words** (science style). This is the primary safeguard ensuring character count stays within range.

5. **VOICEOVER PACING** *(see `02_output_format.md`)*
   - Every scene consists of **exactly one complete, natural sentence**.
   - **No Scene Word Limits:** There is NO minimum or maximum word limit per scene. Write the voiceover naturally, ensuring the text flows like a real speech.
   - The script must feel like a rapid succession of mind-blowing punches, with each punch being a single, powerful sentence.

6. **TONE & ENERGY**
   - Use highly dramatic, urgent, and emotionally exaggerated language.
   - Prioritize shock, scale, mystery, or extreme comparisons.
   - Avoid long-winded explanations, background details, or introductory filler. Dive straight into the climax of the story.

7. **NARRATIVE ARC (4-Beat Model)**
   - You MUST load and follow `rules/story_arc.md`.
   - Short videos follow a compressed but complete storytelling arc.

   - **HOOK (≤15% of total scenes)**
     - Immediately stop the scroll with a shocking fact, absurd comparison, or provocative question.

   - **ESCALATION (35-45% of total scenes)**
     - Progressively layer information.
     - Every scene should introduce a meaningful new idea, fact, comparison, or implication.
     - Continuously increase curiosity or dramatic tension.

   - **PEAK (30-35% of total scenes)**
     - Deliver the strongest revelation.
     - Fulfill the promise established by the Hook.

   - **EXIT (10-20% of total scenes)**
     - End with a memorable conclusion, philosophical implication, surprising twist, or cliffhanger, followed by a natural CTA (subscribe, comment, share).

   **Note:** Apply these percentages to the actual planned scene count (16-20) to compute real scene numbers for THIS video. Do not treat any fixed scene-number range as universal — the percentage is the source of truth, the scene numbers are its output.

   **INFORMATION DENSITY**
   - Every scene MUST introduce at least ONE meaningful new element.
   - Never create scenes that merely restate previous information using different wording.

8. **ANTI-LAZINESS (STRICTLY ENFORCED)**
   - Every `main_idea`, `voiceover`, and `veo_prompt` MUST contribute genuinely new content.
   - Avoid repeating the same visual concept, sentence structure, or narrative technique across consecutive scenes.
   - Every `veo_prompt` MUST meaningfully change the subject, action, environment, camera angle, composition, lighting, or perspective.
   - Changing only adjectives, colors, wording, or labels such as "Variation 1" does NOT satisfy this requirement.
   - Consecutive scenes should naturally connect through escalation, comparison, cause and effect, or logical progression.
   - Avoid overusing rhetorical transitions such as "Nhưng...", "Chưa hết...", or "Điều đáng kinh ngạc là...". Use them only when they genuinely improve storytelling.

---

## MEASUREMENT UNITS — WHY CHARACTERS, SCENES, AND WORDS?

This system intentionally uses three different measurement units because each controls a different aspect of the final video.

| Unit | What It Controls | Why |
|------|-----------------|-----|
| **Total Characters (900-1200)** | Overall video duration | Ensures the complete narration lasts approximately **45-60 seconds**, making it suitable for YouTube Shorts. |
| **16-20 Scenes (one sentence per scene)** | Story pacing and visual rhythm | Each scene is exactly one natural sentence, ensuring organic flow and clean editing cuts. |
| **No Per-Scene Limits** | Natural narration speed | Voiceover is written naturally without artificial word limits per scene, as long as the total length is within range. |

These measurements serve different purposes and should NOT be converted into one another. Overall video duration is controlled by total characters, visual pacing is controlled by scene count, and narration pacing is controlled by the target scene duration.