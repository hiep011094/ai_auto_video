---
trigger: always_on
---

# STRICT OUTPUT FORMAT DIRECTIVES

To ensure the WebApp processes generated projects accurately, you **MUST** strictly adhere to the following data structures and file generation workflows.

## 1. UPDATE HISTORY (`database/history.json`)
After determining the `youtube_title`, you MUST append a new object to the array in `database/history.json` with the following schema:
```json
{
  "id": "uuid-v4-random",
  "title": "[Video Title]",
  "folder": "[youtube_title]",
  "date": "YYYY-MM-DDTHH:mm:ss.sssZ", // MUST be true UTC time. Do NOT just append 'Z' to the current local time string! Convert the local time to UTC by subtracting the timezone offset (e.g. if local time is 17:53:11 in UTC+7/ICT, subtract 7 hours to get 10:53:11 before formatting as 'Z').
  "type": "short", // or "long"
  "voiceStyle": "...", // the voiceStyle used for this video
  "last_hook_pattern": 1 // integer 1-5, the hook pattern number used in Scene 1, per the active voice_*.md file. MANDATORY for ALL voiceStyle values, not just street_humor.
}
```
Note: `folder` must be a safe, slugified string (e.g., `the_truth_about_black_holes`).

## 2. CREATE PROJECT DIRECTORY
Based on the `videoType` of the script, you MUST create the project directory inside the corresponding parent folder:
- If `videoType="short"`: Create the directory at `data/video_short/[folder]`
- If `videoType="long"`: Create the directory at `data/video_dai/[folder]`
(Use the exact `folder` name saved in `history.json`). Create the parent directory (`video_short` or `video_dai`) if it does not exist.

## 3. METADATA FILE (`[project_dir]/metadata.json`)
You MUST generate a `metadata.json` file inside the project directory containing SEO data for YouTube:
```json
{
  "title": "Compelling, SEO-optimized title. You MUST include EXACTLY 1 hashtag at the end of the title (If short video: it MUST be #shorts).",
  "description": "Line 1: Title (but remove all hashtags). Line 2+: SEO-optimized description written for humans, naturally incorporating the primary topic keywords. Last Line: 3 to 5 hashtags total (see HASHTAG STRATEGY below). ABSOLUTELY DO NOT repeat any hashtag already used in the title.",
  "keywords": [
    "keyword 1", "keyword 2", "..." // Exactly 20 highly-searched, professional SEO keywords/phrases — this is the primary SEO surface, NOT the hashtags. These populate the video's backend tags field.
  ],
  "videoType": "short", // or "long"
  "mode": "1", // or "2"
  "language": "...",
  "voiceStyle": "...",
  "sources": ["https://source1.com/article", "https://source2.com/data"]  // OPTIONAL. Required ONLY when mode == "2" (Fact). List all URLs used during research. Minimum 3 credible sources.
}
```

**⚠️ HASHTAG STRATEGY (REVISED — MANDATORY):**
- **Total hashtags across title + description: 3 to 5 maximum, never more.** YouTube ignores ALL hashtags on a video once the total crosses its platform threshold, so more hashtags does NOT mean more reach — it risks nullifying every hashtag on the video, including the ones that would have worked.
- **Composition of the 3-5 hashtags:**
  1. One broad category hashtag (e.g., `#space`, `#science`).
  2. One niche/topic-specific hashtag (e.g., `#blackhole`, `#khamphavutru`).
  3. One video-specific hashtag describing the exact subject.
  4-5. (Optional) One or two hashtags only if genuinely relevant — do not pad to reach a number.
- **DO NOT use generic "discovery" hashtags** like `#fyp`, `#foryou`, `#viral`, `#trending`, `#xuhuong`, `#fypシ`. These are TikTok/Instagram conventions with no proven algorithmic effect on YouTube, and repeating the same generic set on every video is a pattern YouTube's spam detection is specifically designed to flag.
- **If `videoType == "short"`:** `#shorts` (or `#short`) MUST be one of the hashtags, ideally placed first so it appears above the title.
- **NO DUPLICATE hashtags** between `title` and `description`. Every hashtag must be unique across the entire metadata.
- **Real SEO work belongs in `keywords`, not hashtags.** The 20-item `keywords` array (backend tags) is where topic coverage and search-term variety should live — it has no equivalent "ignore everything" penalty and is the field YouTube's search/suggestion system actually weighs.

## 4. CHAPTER FILES (`[project_dir]/chapter_xx.json`)
The script MUST be split into multiple files named `chapter_1.json`, `chapter_2.json`, etc., and saved in the project directory.
Each file contains a JSON array of video scenes.
- **SCENE DURATION (FLEXIBLE):** Each scene represents a flexible duration to allow natural speech flow. The target duration is:
  - **Short Video:** Each scene represents **exactly one complete, natural sentence** (no forced duration, but fits the spoken sentence).
  - **Long Video:** Under 8 seconds per scene (ideal range: **3 to 8 seconds**, must NOT exceed 8 seconds).
  The voiceover text length must be naturally written to fit within these limits.
- **⚠️ VOICEOVER WORD COUNT (FLEXIBLE CEILING):**
  - **Short Video:** There is NO per-scene word limit (no minimum, no maximum). The only hard rule is that **each scene MUST contain exactly one complete, natural sentence**. You are strictly forbidden from splitting a single sentence across multiple scenes, or putting multiple sentences in a single scene.
  - **Long Video:** Vietnamese: **15–40 words per scene** (max ceiling: 40 words, target: 20-35 words). English: **10–25 words per scene** (max ceiling: 25 words). Treat the maximum as a ceiling, not a target — see `video_long.md` Rule 4.
  - **Self-Check Protocol:** After writing each `voiceover`, silently count the words. For long videos, if it exceeds the maximum, CUT IT DOWN or split. For short videos, ensure it is exactly one sentence. Then after writing ALL scenes: (1) count total characters — if outside range (Short standard: 900–1200, Short science: 950–1350, Long: >10,000), adjust; (2) count total words across all scenes — Short standard must be 200–260 total words, Short science must be 180–230 total words. If either check fails, redistribute — do not pad with filler.
- **SCENE NUMBERING:** The `scene` number MUST increment continuously across ALL chapters. (Example: If `chapter_1.json` ends at `scene: 15`, then `chapter_2.json` MUST start at `scene: 16`. NEVER reset to 1).
- **SCHEMA:**
```json
[
  {
    "scene": 1,
    "voiceover": "Perfectly timed dialogue for the scene.",
    "emotion_tag": "hook",  // OPTIONAL but strongly recommended. One of: hook, tension, reveal, awe, calm, urgency, reflection. Helps Phase 4 match visual tone to narrative intent.
    "main_idea": "Visual/context analysis for this scene. ABSOLUTELY DO NOT copy/paste the voiceover here. You must infer an independent visual concept.",
    "veo_prompt": "English prompt based on the inferred visual style. YOU ARE STRICTLY FORBIDDEN from copying previous prompts. Every scene MUST have a 100% UNIQUE prompt."
  },
  {
    "scene": 2,
    "voiceover": "...",
    "main_idea": "...",
    "veo_prompt": "..."
  }
]
```

## STRICT SYSTEM RULES:
- The data inside `chapter_xx.json` MUST be an Array.
- DO NOT invent or add any fields outside of the defined schema.
- **ANTI-LAZINESS PROTOCOL:** When writing long scripts, you are STRICTLY FORBIDDEN from copy-pasting the `veo_prompt` or `main_idea` from previous scenes. Every single scene must be a 100% unique creative output.
- You MUST generate ALL required files BEFORE terminating your workflow (marking the queue status as completed).