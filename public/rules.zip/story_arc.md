---
trigger: always_on
---

# STORY ARC ENGINE — NARRATIVE STRUCTURE BLUEPRINTS

Every script MUST follow a structured narrative arc. The Agent does NOT just "list facts" — it tells a STORY with emotional beats, tension, and resolution. **Load `rules/craft_dramaturgy.md` alongside this file** — the beats below define WHEN things happen; `craft_dramaturgy.md` defines HOW to make each beat land with professional craft (dramatic question, escalation by stakes, show-don't-tell, callback, subtext).

---

## 1. SHORT VIDEO ARC (4-Beat Model)
For `videoType == "short"` (16-20 scenes, ~60 seconds).
Short videos are fast-paced punches. Every second counts. The arc is compressed but complete.

| Beat | % of Total Scenes | Purpose | Description |
|------|--------------------|---------|-------------|
| **HOOK** | ≤15% (max 3 scenes) | Grab & Hold + Raise the CDQ | A shocking fact, absurd comparison, or provocative question that stops the scroll — and implicitly plants the Central Dramatic Question (`craft_dramaturgy.md` §1). The audience must feel: "Wait, WHAT?" within 3 seconds. |
| **ESCALATION** | 35-45% | Build Tension via Stakes | Layer information progressively, but each scene must raise Threat, Proximity, or Paradox versus the last (`craft_dramaturgy.md` §3) — not just add a fact. The audience must feel: "Tell me MORE." |
| **PEAK** | 30-35% | Climax & CDQ Payoff | The most dramatic, mind-blowing revelation. This is the moment the audience gasps. MUST directly resolve the CDQ raised in the HOOK (`craft_dramaturgy.md` §1) — never a different question. The audience must feel: "No way!" |
| **EXIT** | 10-20% | Reflection & CTA | A thought-provoking conclusion or a cliffhanger that lingers, specific to this CDQ (not a generic moral — `craft_dramaturgy.md` §6). A callback to the HOOK's opening image is encouraged (`craft_dramaturgy.md` §5). End with a Call-to-Action (subscribe, comment, "What do you think?"). The audience must feel: "I need to share this." |

**Note:** Apply these percentages to the actual planned scene count (16-20) to compute real scene numbers — do not treat fixed ranges like "17-20" as universal.

### Scene Distribution Rules:
- **HOOK must occupy ≤ 15% of total scenes** (no more than 3 scenes). Don't waste time on a slow build.
- **ESCALATION must occupy 35-45% of total scenes.** This is the meat of the content.
- **PEAK must occupy 30-35% of total scenes.** Give the payoff enough room to breathe.
- **EXIT must occupy 10-20% of total scenes.** Short, punchy, memorable.

---

## 2. LONG VIDEO ARC (7-Beat Documentary Model)
For `videoType == "long"` (3-10 chapters, each chapter up to 10 scenes — see `video_long.md`).
Modeled after National Geographic, BBC Earth, and Discovery Channel documentary structure. This is NOT a school lecture — it's a cinematic journey.

Because the chapter count is now variable (3 to 10), beats are mapped by **percentage of total chapters**, not fixed chapter numbers. Always compute the percentages against the ACTUAL number of chapters you plan for this specific video.

| Beat | Chapter Mapping (% of total chapters) | Purpose | Description |
|------|----------------------------------------|---------|-------------|
| **HOOK** | First ~10-15% of chapters (always at least the first chapter) | Instant Captivation + Plant CDQ | An arresting opening image, shocking statistic, or cinematic cold open. Implicitly plants the Central Dramatic Question (`craft_dramaturgy.md` §1). The viewer must be locked in within 5 seconds. |
| **QUESTION** | Remainder of the first ~15-20% of chapters | Explicitly Frame the CDQ | State the central question of the documentary directly: "WHY does this happen?", "HOW is this possible?", "WHAT if...?". The viewer must feel intellectually invested. |
| **EVIDENCE** | Next ~25-30% of chapters | Build the Case via Stakes | Present supporting data, historical context, and research — each new piece must also raise Threat, Proximity, or Paradox (`craft_dramaturgy.md` §3), not just stack facts. Build credibility. |
| **CONFLICT** | Next ~15-20% of chapters | Create Tension | Introduce the counterargument, the unsolved mystery, the paradox, or the catastrophic consequence. This is where the documentary earns its drama. The viewer must feel: "But wait..." |
| **DISCOVERY** | Next ~15-20% of chapters | CDQ Payoff | The breakthrough, the revelation — MUST directly resolve the CDQ raised in HOOK/QUESTION (`craft_dramaturgy.md` §1), never a substituted question. The viewer must feel: "Oh, NOW I understand!" |
| **CONCLUSION** | Next ~10% of chapters | Synthesize | Pull all threads together. Summarize the journey. Restate the central insight with newfound depth. |
| **REFLECTION** | Final ~5-10% of chapters (always the last chapter) | Callback + Subtext + CTA | MUST callback at least one specific HOOK detail with new recontextualized meaning (`craft_dramaturgy.md` §5), and close with an ending specific to this CDQ, not a generic moral (`craft_dramaturgy.md` §6). Leave the viewer with a sense of awe, curiosity, or existential wonder. End with a strong CTA. |

**Worked examples:**
- **3 chapters total** *(~3,900 chars at target pacing — below mid-roll threshold. Suitable only for focused topics that resolve quickly. See `video_long.md` Rule 2 for the full math.)*: Chapter 1 = HOOK + QUESTION. Chapter 2 = EVIDENCE + CONFLICT + DISCOVERY (compressed). Chapter 3 = CONCLUSION + REFLECTION.
- **6 chapters total** *(~7,800 chars — below mid-roll threshold. Useful for medium-depth topics)*: Chapter 1 = HOOK + QUESTION. Chapters 2-3 = EVIDENCE. Chapter 4 = CONFLICT. Chapter 5 = DISCOVERY. Chapter 6 = CONCLUSION + REFLECTION.
- **10 chapters total** *(~13,000 chars — comfortably monetizable)*: Chapter 1 = HOOK + QUESTION. Chapters 2-4 = EVIDENCE. Chapters 5-6 = CONFLICT. Chapters 7-8 = DISCOVERY. Chapter 9 = CONCLUSION. Chapter 10 = REFLECTION.

### Chapter-to-Beat Mapping Rules:
- **The first chapter** MUST contain the HOOK and QUESTION beats. These two beats establish the contract with the viewer: "Stay with me, and I'll show you something incredible."
- **The middle chapters** carry EVIDENCE, CONFLICT, and DISCOVERY, distributed proportionally per the percentage table above. These are the densest chapters.
- **The final chapter** MUST contain CONCLUSION and REFLECTION (or REFLECTION alone if CONCLUSION was folded into the prior chapter). Never end a documentary abruptly without reflection.
- **CONFLICT is mandatory regardless of chapter count.** A documentary without tension is a Wikipedia article. Even purely educational topics must have a "turning point" (e.g., "Scientists thought X for decades... until THIS discovery changed everything.").
- **Do not artificially stretch a beat across more chapters just because more chapters are available.** If the topic naturally resolves in 4 chapters, use 4 — the 3-10 range is a ceiling for complex topics, not a target to fill.

---

## 3. CHAPTER RE-HOOK RULE (applies whenever a video has 2+ chapters)
Hook Diversity rules in the `voice_*.md` files protect Scene 1 of the whole video, but each new chapter is also a point where a viewer can drop off (natural break, potential ad boundary, attention reset).

- The **first scene of every chapter AFTER the first chapter** (i.e., the opening of Chapter 2, 3, ... up to Chapter 10) MUST function as a **mini re-hook**, not a flat continuation.
- Use one of: a callback to the unresolved tension left at the end of the previous chapter, a new sharp rhetorical question, a surprising fact that reframes what came before, or a direct address to the viewer — always in the same Voice Style as the rest of the video.
- **Forbidden openers** for a new chapter: flatly resuming narration with phrases that signal "just continuing a list," e.g. "Tiếp theo, chúng ta sẽ tìm hiểu về..." / "Next, let's look at...". These read as filler and give the viewer permission to leave.
- **Rotate the re-hook technique across chapters** in the same video — do not use the identical re-hook pattern (e.g., always a rhetorical question) at every chapter boundary.

---

## 4. CATCHPHRASE FATIGUE GUARD (long videos only)
Signature slang, catchphrases, and running jokes (e.g., "trời đất ơi", "quá trời quá đất", "mấy bà ơi", or any recurring exclamation defined in the active `voice_*.md` file) add personality, but repeat too often across a long video (up to 120 scenes) and become mechanical.

- Do **NOT** reuse the exact same catchphrase more than **once per chapter**.
- Vary the humor/emphasis device between chapters: alternate between slang exclamation, rhetorical question, absurd comparison, and pop-culture-style reference, so no two consecutive chapters lean on the same joke mechanism.
- This rule applies on top of, not instead of, the Hook Diversity rules already defined in each `voice_*.md` file.

---

## 5. BEAT ASSIGNMENT PROTOCOL
When writing the outline in Phase 2, the Agent MUST:
1. **Define the Central Dramatic Question (CDQ)** per `craft_dramaturgy.md` §1 — before assigning any scene to a beat.
2. **Define the Narrator POV Sheet** per `craft_dramaturgy.md` §2.
3. **Assign every scene to exactly one beat.** No scene should exist without a narrative purpose.
4. **Label each beat internally** (this is for the Agent's planning only, not exported to JSON).
5. **Verify beat distribution** matches the percentages above during Quality Gate 2 — for long videos, compute percentages against the actual chosen chapter count, not a fixed number.
6. **Ensure beats flow in order.** You cannot jump from HOOK to DISCOVERY. The arc must progress naturally.
7. **Plan the Escalation-by-Stakes axis** (Threat/Proximity/Paradox) for each ESCALATION/EVIDENCE/CONFLICT scene per `craft_dramaturgy.md` §3.
8. **For long videos, additionally verify** the Chapter Re-Hook Rule (Section 3), Catchphrase Fatigue Guard (Section 4), and identify the specific HOOK detail to be called back in REFLECTION per `craft_dramaturgy.md` §5.