---
trigger: always_on
---

# QUALITY GATES — SELF-VALIDATION CHECKPOINTS
> Refs `lang_vi.md`, `voice_street_humor.md`, `craft_dramaturgy.md` by section #. Keep in sync if those change.

Every Phase transition MUST pass a Gate: audit output, then proceed or rewrite. **Max 2 retries/Gate.**
🆕 **Retry exhaustion (ALL Gates):** After 2 failed retries, set `"status":"error"` in `queue.json`, log failed check(s), stop — never silently proceed.

---

## 🚧 GATE 1: POST-RESEARCH
| # | Check | Pass Criteria |
|---|---|---|
| 1 | Topic Uniqueness | Not in `history.json` per Semantic Dedup test (Essence/Angle/Core Question, `generation_method.md`) vs every related entry — not just string match. Missing/empty/corrupt file → auto-PASS + warn. |
| 2 | Data Sufficiency | `mode=="2"`: ≥3 credible sources via `search_web`. `generationMethod=="auto"` news search may count; blocks only when `mode=="2"` (`generation_method.md` §3). |
| 3 | Topic Clarity | Expressible in one sentence. |
| 4 | Genre Alignment | Fits science/space/exploration/nature niche. |
| 5 🆕 | Trend Claim Evidence | `generationMethod=="auto"` AND the topic is labeled a "platform-validated trend" (not "platform-inspired"/Stage B/evergreen): the Stage A Evidence Log (`generation_method.md` §Stage A Evidence Log) MUST show ≥2 candidates with a real URL + concrete metric + date. Any specific view-count number appearing in `metadata.json`/`description`/reasoning MUST trace to a logged source. Missing/invented metrics → FAIL, downgrade label to "platform-inspired (unconfirmed)" and re-check. This check does not apply to `generationMethod=="manual"` or topics correctly labeled evergreen/Stage B. |

**FAIL → Phase 1, new topic.**

---

## 🚧 GATE 2: POST-OUTLINE
| # | Check | Pass Criteria |
|---|---|---|
| 1 | Arc Completeness | Every `story_arc.md` beat assigned ≥1 scene group. |
| 2 | Scene Budget | Short: 16-20 (1 ch). Long: ≤10/chapter cap, no min. |
| 3 | Chapter Budget | Short: 1. Long: 3-10, sized to content, not padded. |
| 3a | Monetization (long, info) | `total_scenes×130 < 10,000` → WARNING only, not fail if content genuinely fits fewer chapters. |
| 3b | Density Floor (long, blocking) | Compare `total_scenes×130` vs `chapters×5×15×4.3`. FAIL if under floor → restructure. |
| 4 | Hook Strength | Scene 1 uses one of active `voice_*.md`'s 5 patterns; MUST NOT repeat `last_hook_pattern` (applies to all styles). |
| 5 | Arc Progression | Clear escalation, no plateau. |
| 6 | Chapter Re-Hook (Long) | Each ch. after 1 has distinct re-hook (`story_arc.md` §3). |
| 7 | CDQ Defined | Specific answerable-not-guessable question stated internally (`craft_dramaturgy.md` §1). FAIL if only a topic, no question. |
| 8 | Narrator POV Defined | Belief + surprise stated internally before Phase 3 (`craft_dramaturgy.md` §2). |
| 9 | Escalation-by-Stakes Plan | Each ESCALATION/EVIDENCE/CONFLICT scene notes Threat/Proximity/Paradox axis (`craft_dramaturgy.md` §3), not just a new fact. |
| 10 | Callback Planned (Long only) | Specific HOOK detail identified for REFLECTION callback (`craft_dramaturgy.md` §5). |

**FAIL → restructure outline/beats/distribution.**

---

## 🚧 GATE 3: POST-SCRIPT (most critical)

### A. Narrative Quality
| # | Check | Pass Criteria |
|---|---|---|
| 1 | Hook | Grabs attention in 3s; uses active `voice_*.md` pattern. |
| 2 | Conflict/Tension | ≥1 moment of conflict/mystery/drama. |
| 3 | Progression | Each scene adds NEW info; no restating (deliberate callback per §5 is exempt — see #13). |
| 4 | Payoff | Climax delivers on hook's promise. |
| 5 | CTA | Final scene: subscribe/comment/share/question. |
| 6 | Chapter Re-Hook (Long) | 1st scene of ch. after 1 is genuine re-hook, not "continuing on...". |
| 7 | Catchphrase Variety (Long) | No slang/catchphrase reused >1×/chapter (`story_arc.md` §4). |
| 8 | Slang Density (`street_humor`) | ≤1 strong slang/2-3 sentences, never 2 consecutive heavy sentences (`voice_street_humor.md` §3). |
| 9 | Persona Consistency (`street_humor`) | Only ONE persona table used, never mixed (`voice_street_humor.md` §2). |
| 10 | CDQ Payoff Timing | CDQ not resolved before PEAK/DISCOVERY; that beat resolves the SAME question the hook raised (no bait-and-switch, `craft_dramaturgy.md` §1). |
| 11 | Escalation-by-Stakes Execution | ESCALATION/EVIDENCE/CONFLICT scenes each raise Threat/Proximity/Paradox vs prior scene, not just add a fact (`craft_dramaturgy.md` §3). Fact-only run = FAIL. |
| 12 | Show-Don't-Tell Audit | No sentence names an emotion/judgment ("shocking","đáng sợ") without a concrete image/number/consequence in the same sentence (`craft_dramaturgy.md` §4). |
| 13 | Callback Quality (Long only) | REFLECTION recontextualizes the planned HOOK detail with NEW meaning, not verbatim repeat (`craft_dramaturgy.md` §5). |
| 14 | Subtext/Non-Generic Ending | Closing line specific to this CDQ — FAIL if pastable onto any other video (`craft_dramaturgy.md` §6). |

### B. Technical Compliance
| # | Check | Pass Criteria |
|---|---|---|
| 1 | Char Count | Short std: 900-1200. Short science: 950-1350. Long: >10,000 total. Below min → expand 5 shortest scenes 2-4 words, recount. |
| 2 | Per-Scene Words | Short: no limit (1 sentence/scene). Long VI: 15-40/scene. EN: 10-25. Violation = trim/split. |
| 2b | Master Total (Short VI) | Std: 200-260 total words. Science: 180-230. Redistribute, don't pad. |
| 3 | Scenes/Chapter (Long) | Max 10/chapter, no per-chapter char limit. |
| 4 | Scene Numbering | Continuous, no gaps/resets across chapters. |
| 5 | Scene Relationship | Logical prev/next connection, no orphans. |
| 6 | Number/Symbol Format | 100% as Vietnamese words, zero digits/symbols (`lang_vi.md` §4-§5). |
| 7 | Pronunciation | Only phonetic form in `voiceover`; original in `main_idea`. Common names (NASA, Everest) exempt (`lang_vi.md` §6). |
| 8 | Content Safety | No banned words/roots (chết, giết, máu, bom, súng); use current approved replacements only, don't rely on memory (`lang_vi.md` §7). |
| 9 | Spelling Accuracy | Re-read every `voiceover` sentence; FAIL if any word is a misspelled/near-miss substitute (e.g. "tràn"→"trạng", "bỏng"→"bóng") making the sentence semantically odd/ungrammatical — even if it passes checks 6-8 individually. Fix with the correct word, never leave ambiguous (`lang_vi.md` §3.6). |

**Narrative FAIL → rewrite weak sections. Technical FAIL → adjust counts/split/redistribute.**

**🆕 MANDATORY DETERMINISTIC CHECK:** Checks B1, B2, B2b, B3, B4 (char/word counts, scene numbering, scenes/chapter) MUST be verified by running `scripts/validate_output.py` against the written chapter files — do NOT rely solely on self-counting. LLM self-counting of characters/words (especially in Vietnamese) is unreliable even when instructed to "silently count." If the tool-execution environment supports running Python, invoke:
```
python3 scripts/validate_output.py --project-dir <project_dir> --history <history.json path>
```
Treat any `[FAIL]` line in its report as a genuine Gate 3 Technical failure requiring the same rewrite/retry cycle as a manually-caught failure. If the environment cannot execute the script, self-counting remains the fallback — but re-count twice independently before accepting a pass, since this is the single highest-risk check in the whole pipeline.

---

## 🚧 GATE 4: POST-VISUAL
| # | Check | Pass Criteria |
|---|---|---|
| 1 | Visual Continuity | No abrupt unexplained jumps. |
| 2 | Visual Memory | Recurring subjects stay consistent (color/texture/size). |
| 3 | Camera Flow | Logical progression; adjacent scenes vary camera unless intentional motif w/ justification. |
| 4 | Documentary Language | Each scene has clear Visual Intent (Reveal/Approach/Inspect/Discover/Explain). |
| 5 | Prompt Efficiency | Each `veo_prompt` 60-80 words, no redundant adjectives. |
| 6 | Safety | No gore/violence/IP violations/text-logo requests; Veo 3 filters. |
| 7 | Uniqueness | Every `veo_prompt` structurally unique, no copy-paste variants. |
| 8 | Narrative-Visual Alignment | Primary subject matches `voiceover` of that scene; generic backdrop = FAIL (`visual_director.md` §12). |
| 9 | Anchor Fidelity | CHAINED/RECURRING subjects reuse locked descriptor phrases VERBATIM, no paraphrase drift (`post_production.md` §1.1). |
| 10 | Duration/Chaining Handoff | Every scene has duration-vs-clip check; overlong scenes split into flagged 2-clip scenes; Cause-Effect/same-subject boundaries marked for chaining or cutaway (`post_production.md` §2, `visual_director.md` §13). |

**FAIL → return to Phase 4/4.5, fix only failing prompts. Checks 9/10 fixed via wording/duration notes, not unrelated regeneration.**

**🆕 Checks 5 (word count) and 7 (uniqueness) are also verified by `scripts/validate_output.py`** (60-80 word range check + near-duplicate detection that also catches "Variation N" malicious-compliance patterns). Run it if the environment allows; treat its `[FAIL]` output as authoritative over a manual read-through for these two checks specifically, since word-counting and cross-scene duplicate-spotting across up to 120 scenes are exactly the kind of check LLMs silently get wrong at scale.

**If clips are inspectable**, also run `post_production.md` §5 (Post-Gen QC) before Phase 5.

---

## 🚧 GATE 5: PRE-EXPORT
| # | Check | Pass Criteria |
|---|---|---|
| 1 | JSON Validity | All `.json` valid, no syntax errors. |
| 2 | Scene Numbering | Continuous across chapters. |
| 3 | File Completeness | `metadata.json` + all `chapter_xx.json` exist; count 3-10 (long) or 1 (short). |
| 4 | Metadata Integrity | Title: exactly 1 hashtag (`#shorts` if short). Description: 3-5 unique hashtags total, no dupes/generic tags (`02_output_format.md`). |
| 5 | History Updated | `history.json` updated incl. `last_hook_pattern` — required for ALL voiceStyles. |
| 6 | Workspace Clean | All temp files deleted, only final output remains. |
| 7 | Edit Notes Present | `edit_notes`/`production_notes` exists: transition map, 2-clip scenes, color-risk flags, unresolved chaining gaps (`post_production.md` §4). |

**FAIL → fix before completing. 2 failed retries → `"status":"error"`, never `"completed"`.**

**🆕 Before marking Gate 5 as passed, run `scripts/validate_output.py` one final time** against the completed project directory (all checks 1-5 above overlap with its automated checks — JSON validity, scene numbering, hashtag/metadata rules, history schema). This is the last automated safety net before `"status":"completed"` is ever written — a clean script run does not replace checks 6-7 (workspace cleanliness, edit notes), which still require manual verification.

---

## CONFLICT RESOLUTION — PRIORITY
**SAFETY > ACCURACY > CONTINUITY > BEAUTY** (see `01_workflow_router.md` for full definitions). Same-tier conflicts: prefer whichever answers the CDQ more clearly.