---
trigger: always_on
---

# NARRATOR VOICE STYLE (voiceStyle = "humor")

1. The `voiceover` MUST be written in a **Humorous, Satirical, and Witty** tone.
2. Use a playful, cheerful, and friendly tone, as if chatting casually with a friend.
3. Use relatable metaphors, everyday analogies, and jokes to explain dry scientific facts.
4. Highly suitable for fast-paced entertainment platforms like TikTok and YouTube Shorts.

## ⚠️ HOOK DIVERSITY (SCENE 1 — CRITICAL FOR RETENTION)
**Rotate between these 5 opener patterns. NEVER repeat the same hook type as the previous video.**

| # | Pattern | Vietnamese Example | English Example |
|---|---------|-------------------|-----------------|
| 1 | **Absurd Comparison** | "Hố đen nặng bằng 40 tỷ mặt trời. Tức là nặng hơn cái bill điện nhà bạn tháng 7." | "A black hole weighs 40 billion suns. That's heavier than your July electricity bill." |
| 2 | **Relatable Complaint** | "Ai đời hành tinh mà cũng biết drama? Nó bị thiên hà đuổi khỏi nhà luôn á!" | "Imagine a planet that got kicked out of its own galaxy. Even planets have family drama." |
| 3 | **Fake News Flash** | "TIN NÓNG: Mặt Trời vừa thông báo sẽ nghỉ hưu trong 5 tỷ năm nữa. Ai xin nghỉ phép trước?" | "BREAKING: The Sun just announced retirement in 5 billion years. Who's requesting time off first?" |
| 4 | **Self-Deprecating** | "Tui tưởng cuộc đời tui khổ, ai dè có hành tinh mưa thủy tinh 8000 km/h." | "I thought MY life was tough, then I learned there's a planet where it rains glass at 5,000 mph." |
| 5 | **Pop Culture Twist** | "Nếu Thanos biết hành tinh này, chắc ổng búng tay hai lần cho chắc." | "If Thanos knew about this planet, he'd snap twice just to be safe." |

---

## HOOK PATTERN TRACKING
See `hook_pattern_tracking.md` (shared across all voice styles) for the full mandatory before/after Scene-1 procedure — do not duplicate that logic here.
