---
trigger: always_on
---

# HYPOTHESIS MODE (mode = "1")

1. **IMAGINATIVE STORYTELLING:** The plot must be highly speculative and imaginative (e.g., "What if the Earth stopped spinning?", "What if you fell into a black hole?").
2. **PRIORITIZE DRAMA:** 100% factual accuracy is not strictly required. Prioritize dramatic tension, catastrophic scenarios, and captivating "What if" logic.
3. **TITLE TAG:** The generated video title MUST always end with the tag `[Hypothesis]` (or `[Giả Thuyết]` if the language is Vietnamese).

---

## SAFETY GUARDRAILS FOR SPECULATION
Even though Hypothesis mode allows creative freedom, it is NOT a license to spread misinformation or create harmful content.

### Rules:
1. **Mandatory Disclaimer in Hook:** The first or second scene MUST establish that this is a thought experiment, not established science. Use phrases like:
   - VI: "Hãy tưởng tượng...", "Điều gì sẽ xảy ra nếu...", "Đây chỉ là giả thuyết, nhưng..."
   - EN: "Imagine if...", "What would happen if...", "This is purely hypothetical, but..."
2. **Grounded Speculation:** Even fictional scenarios should be rooted in real scientific principles. "What if the Moon disappeared?" should use real physics (tidal effects, axial tilt changes), not fantasy magic.
3. **Drama Ceiling:** Catastrophic scenarios are encouraged, but MUST NOT cross into:
   - Depicting real-world tragedies (e.g., specific terrorist attacks, named natural disasters with victims)
   - Content that could be interpreted as threats or instructions for harm
   - Scenarios that promote conspiracy theories as plausible (e.g., "What if the Earth is actually flat?" should CLEARLY frame this as debunked)
4. **Closing Disclaimer:** The final scene (EXIT/REFLECTION beat) SHOULD remind the viewer that this was speculative:
   - VI: "Tất nhiên, đây chỉ là giả thuyết. Nhưng nó cho ta thấy..."
   - EN: "Of course, this is just a thought experiment. But it shows us..."
5. **Fact vs. Fiction Boundary:** When mixing real science with speculation, use clear verbal markers:
   - ✅ "Theo khoa học, Mặt Trời sẽ tắt trong 5 tỷ năm. Nhưng NẾU nó tắt NGAY BÂY GIỜ..."
   - ❌ Seamlessly blending real facts and fictional consequences without any distinction