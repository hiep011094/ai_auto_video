---
trigger: always_on
---

# SCRIPT LANGUAGE RULES (language = "vi")
> Read in order. Lower-numbered sections override higher-numbered ones on conflict.
> Instructions are in English for deeper model comprehension. All Vietnamese text inside quotes/examples must be reproduced exactly as shown — do not translate the Vietnamese examples themselves.

## 0. QUICK REFERENCE — Check before writing any sentence
| Need to write | Never write | Convert to (Vietnamese) |
|---|---|---|
| Numbers | `1086`, `15%`, `3.14` | Spell out 100% in Vietnamese words: "một nghìn không trăm tám mươi sáu", "mười lăm phần trăm", "ba phẩy mười bốn" |
| Units | `km/h`, `°C`, `kg` | "ki-lô-mét mỗi giờ", "độ C", "ki-lô-gam" |
| Symbols | `%`,`+`,`-`,`x`,`/`,`>`,`<`,`~`,`^`,`$`,`&`,`:` | See table §4 |
| Foreign proper names | James Webb, Hubble... | Vietnamized phonetic spelling — see table §5 (NEVER write the original alongside the phonetic version in `voiceover`) |
| Sensitive words | chết, giết, máu, súng... | Safe replacement — see table §7 |
| Large number word | "ngàn" | Default to "nghìn" (only use "ngàn" if target audience is explicitly Southern Vietnam) |

---

## 1. FIELD RULES — Absolute, no exceptions
1.1. `voiceover`: 100% Vietnamese, written to be SPOKEN (not read) — every number/symbol/proper name must already be in its final spoken-word form, ready for direct TTS playback.
1.2. `metadata.json` (title/description/keywords/hashtags): 100% Vietnamese with full diacritics.
1.3. `youtube_title` (folder name): Vietnamese WITHOUT diacritics, underscores instead of spaces. Example: `nhung_su_that_ve_lo_den`.
1.4. `veo_prompt`: ALWAYS English, regardless of the script's target language.
1.5. `main_idea`: preserve the original proper name/catalogue code (English/digits) so the editor can cross-reference for on-screen captions — this is the ONLY field where the original (non-Vietnamized) form is allowed.

---

## 2. VOICE STYLE — Pick exactly one, apply consistently across the entire video
| Style | Signature vocabulary (Vietnamese) | Forbidden |
|---|---|---|
| `epic` | vô tận, nghẹt thở, sụp đổ, tráng lệ, kỳ vĩ | — |
| `mystery` | bí ẩn chưa lời giải, dấu vết, tín hiệu kỳ lạ | resolving the mystery too early |
| `science` | khách quan, điềm tĩnh, thuật ngữ chính xác kèm giải thích | excessive exclamatory language |
| `humor` / `local_humor` / `street_humor` | everyday comparisons (e.g. hố đen ~ ví tiền cuối tháng) | jokes that distort core factual accuracy |
| *(default if unspecified)* | neutral, everyday-accessible tone | overusing "kỳ vĩ", "diệu kỳ", "tráng lệ" |

**Hard rule:** Scientific/historical content must remain 100% accurate regardless of style — style only affects phrasing, never facts.

---

## 3. NATURAL DELIVERY — Verify before finalizing
3.1. **No translationese:** avoid clunky passive constructions ("Nó được tin là..." → rewrite as "Người ta tin rằng..."). Do not repeat "Nó"/"Chúng ta" more than twice in a row — replace with a concrete noun phrase ("ngôi sao này", "vật thể khổng lồ kia").
3.2. **Sentence rhythm:** never more than 3 long sentences in a row. After 1-2 long sentences, insert one short sentence (3-6 words) for emphasis.
3.3. **Natural conversational fillers** (max 2-3 per short video, 4-6 per long video — do NOT overuse):
   - Opening hooks: "Bạn có biết không...", "Nghe thì khó tin nhưng..."
   - Twists: "Vậy mà...", "Ấy thế mà..."
   - Scene transitions: "Nhưng câu chuyện chưa dừng ở đó...", "Rồi mọi chuyện càng lúc càng kỳ lạ..."
   - **Forbidden as connectors:** "Tiếp theo", "Hơn nữa", "Mặt khác" (sounds like a written report, not spoken narration).
3.4. **Accessible vocabulary:** replace academic/formal terms with plain, concrete language. Example: "suy hao quang thông" → "ánh sáng yếu đi"; "khuếch tán" → "lan rộng ra".
3.5. **Regional neutrality:** default to a nationally neutral tone. Only use regional colloquialisms (North/South/Central) when `voice_style` = `local_humor`/`street_humor` AND a specific target region is given — in that case stay consistent with one region throughout, never mix.
3.6. 🆕 **SPELLING & WORD-ACCURACY CHECK (mandatory, applies to every scene):**
   After writing each sentence, ask internally: *"Is this word spelled correctly and does it carry the intended meaning, or did I just type a near-miss word that merely looks/sounds similar?"*
   - Watch for near-miss pairs that are easy to mistype because they look or sound alike but mean something different or nothing at all in context: `"tràn"` ≠ `"trạng"` · `"bỏng"` ≠ `"bóng"` · `"xoáy"` ≠ `"xoay"` · `"giẫm"` ≠ `"dẫm"` · `"sảy"` ≠ `"sẩy"` · `"dành"` ≠ `"giành"` · `"xuất"` ≠ `"suất"` · `"chuẩn"` ≠ `"chẩn"` · `"dòng"` ≠ `"giòng"`. This list is illustrative, not exhaustive — apply the same scrutiny to any word that feels slightly "off."
   - If unsure whether a word actually exists or fits the context correctly, replace it with a synonym you are certain is correct — never guess and leave an ambiguous word in the output.
   - Re-read every finished sentence as a whole: if one word makes the sentence semantically odd, grammatically broken, or nonsensical, that is a sign of a typo/near-miss word — fix it before finalizing, even if the sentence otherwise reads smoothly at a glance.
   - This check is independent of and in addition to §4-§7 (symbols, numbers, proper names, banned words) — a word can be 100% compliant with those tables and still be a plain spelling/word-choice error.

---

## 4. SYMBOLS → WORDS (mandatory 100% conversion, output in Vietnamese)
`%`→"phần trăm" · `+`→"cộng/dương" · `-`→"âm/đến" · `*` `x`→"nhân/gấp...lần" · `/`→"trên/mỗi" · `>`→"lớn hơn" · `<`→"nhỏ hơn" · `~`→"khoảng" · `^`→"mũ" · `°`→"độ" · `$`→"đô-la" · `&`→"và" · `:`→"chia/trên"

**Units:** km/h→"ki-lô-mét mỗi giờ" · km/s→"ki-lô-mét mỗi giây" · m/s→"mét mỗi giây" · km→"ki-lô-mét" · kg→"ki-lô-gam" · °C→"độ C" · K→"độ Ken-vin" · ly (light-year)→"năm ánh sáng" · AU→"đơn vị thiên văn" · Hz/GHz→"héc"/"ghi-ga-héc" · W/kW/MW→"oát"/"ki-lô-oát"/"mê-ga-oát"

---

## 5. NUMBERS (spell out 100%, zero digits allowed in output)
| Case | Wrong | Correct (Vietnamese) |
|---|---|---|
| Large numbers | "1000 tỷ" | "một nghìn tỷ" *(use "nghìn" per §0)* |
| 15 at sentence end | "mười năm" | "mười lăm" (avoid confusing with "năm"=year) |
| 21 at end of tens digit | "hai mươi một" | "hai mươi mốt" |
| Decimals | "3.14" | "ba phẩy mười bốn" |
| Ordinals | "thứ 1" | "thứ nhất" |
| Years | "2023" | "hai nghìn không trăm hai mươi ba" or "hai không hai ba" |
| Catalogue codes (e.g. K2-141b) | keep as-is | "ca hai một trăm bốn mươi mốt bê" (original form stored in `main_idea`) |

---

## 6. PROPER NAME PHONETICS (only the phonetic form goes in `voiceover`; original form goes in `main_idea`)
James Webb→"Giêm Uép" · Hubble→"Háp-bơn" · Kepler→"Kép-lơ" · Voyager→"Voi-dơ" · Stephen Hawking→"Sti-ven Hóc-king" · Albert Einstein→"An-bớt Anh-xtanh" · Andromeda→"An-đrô-mê-đa" · Oumuamua→"Ô-mua-mua" · Milky Way→"Ngân hà" · Big Bang→"Vụ nổ lớn"

**Keep unchanged (no phonetic needed):** NASA, Everest, Mariana, Việt Nam, Trái Đất, Mặt Trăng, Mặt Trời.

**Strictly forbidden:** writing both the original spelling and the phonetic version together in `voiceover` (causes TTS to read it twice). Forbidden mixed English/Vietnamese slang: "tụt mood"→"tụt hứng"; "trend"→"xu hướng"; "livestream"→"phát trực tiếp"; "subscribe"→"đăng ký"; "UFO"→"vật thể bay không xác định"; "DNA"→"đê-en-a".

---

## 7. CONTENT SAFETY FILTER (mandatory — avoids copyright strikes/demonetization)
| Forbidden category | Example forbidden words | Replace with |
|---|---|---|
| Death | chết, tự sát, xác chết, nghĩa địa | mất đi, qua đời, không còn nữa, biến mất, phân rã |
| Violence | giết, tàn sát, ám sát, tra tấn | hủy diệt, loại bỏ, quét sạch, san phẳng |
| Blood/injury | máu, vết thương, chảy máu | thiệt hại nặng nề, hư hại nghiêm trọng |
| Weapons/drugs | súng, đạn, bom, ma túy | vũ khí, thiết bị nổ, chất độc hại, chất cấm |
| Disaster | tai nạn thảm khốc, khủng bố | sự cố lớn, vụ va chạm mạnh |
| Adult content | tình dục, khỏa thân, hiếp dâm | avoid mentioning or describe indirectly |

**For cosmic disaster topics specifically (asteroid impact/supernova/black hole):** describe the physics (energy release, shockwaves, heat) — NEVER describe direct human casualties.
- ❌ "hàng tỷ người chết thảm khốc" → ✅ "sự sống trên hành tinh sẽ hoàn toàn biến mất"

**🆕 Root-word matching (applies across ALL voice styles, including `street_humor`/`local_humor`):** the forbidden words above are banned in ANY phrase containing that root — including casual slang, exclamations, and idioms — not just literal/formal usage. For example, "chết bà", "chết mẹ", "chết cười", "chết đi được", "chết thật" all contain the forbidden root "chết" and are banned, even when used as a lighthearted interjection rather than a literal reference to death. If a voice-style file's slang list (e.g. `voice_street_humor.md` §4) ever conflicts with this table, **this table always wins** — this is a SAFETY-tier rule and per `01_workflow_router.md` it overrides any BEAUTY-tier stylistic choice, no exceptions.

---

## 8. PACING MARKERS — Punctuation as sound direction
`...` = 0.5-1s pause before a reveal · `-` = quick interjected info · `!` = energy spike (hooks, climax) · `.` (consecutive short sentences) = urgent rhythm · `,` = continuous flow

---

## 9. EMOTION CUES
- Never stretch letters ("quááá") — TTS will misread it letter-by-letter. Use an adverb instead: "vô cùng dài".
- Consecutive short sentences convey power: "Vũ trụ lạnh lẽo. Không một bóng người."
- Deliberate word repetition for emphasis: "Nó nóng... nóng hơn bất kỳ lò luyện kim nào."

---

## 10. FINAL CHECK — Run before writing `voiceover` to output
- [ ] Zero remaining digits/symbols/unconverted English words
- [ ] No more than 3 consecutive long sentences
- [ ] 2-3 natural fillers used (within the allowed count)
- [ ] No forbidden words from table §7, including root-word matches in slang/idioms
- [ ] Regional tone consistent throughout
- [ ] `main_idea` retains original names/codes for editor cross-reference
- [ ] `veo_prompt` is in English; all other fields match the language specified in §1
- [ ] 🆕 No misspelled/near-miss words per §3.6 — every sentence re-read as a whole, not just scanned for digits/symbols/banned words