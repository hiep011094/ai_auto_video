---
trigger: always_on
---

# LONG VIDEO RULES (videoType = "long")

1. **PACING**
   - Documentary-style pacing: give each beat room to breathe, but never let any single chapter drag without adding new information or raising stakes.
   - Every scene must serve one of the 7 beats defined in `rules/story_arc.md` §2.

2. **CHAPTER STRUCTURE**
   - Total chapters: **3 to 10**, sized to content — never padded to max just because the range allows it.
   - First chapter MUST contain HOOK + QUESTION. Final chapter MUST contain CONCLUSION + REFLECTION (or REFLECTION alone if CONCLUSION was folded earlier). See `story_arc.md` §2 for the full beat-to-chapter mapping table and worked examples.

3. **SCENE COUNT PER CHAPTER**
   - **Max 10 scenes per chapter (hard cap).** No fixed minimum — a chapter may have as few scenes as the beat genuinely needs.
   - **SCENE NUMBERING:** Must increment continuously across ALL chapters. If `chapter_1.json` ends at `scene: 15`, `chapter_2.json` MUST start at `scene: 16`. NEVER reset to 1.
   - Scene duration target: **3-8 seconds**, must NOT exceed 8 seconds.

4. **MANDATORY LENGTH (per-scene word ceiling — treat as CEILING, not TARGET)**
   - **Vietnamese:** 15-40 words/scene. **Target zone: 20-35 words.** The 40-word figure is a hard ceiling for scenes that genuinely need the extra room (e.g. a complex causal explanation) — it is NOT something to reach for by default. Padding an otherwise-complete 22-word sentence to 38 words with filler is a FAIL just as much as exceeding 40.
   - **English:** 10-25 words/scene, same ceiling-not-target logic (target ~14-20, ceiling 25).
   - **Total video length:** combined `voiceover` characters across all chapters MUST exceed **10,000 characters**.
   - **Self-Check Protocol:** after writing each scene, silently count words. If it exceeds the ceiling, cut or split. After all chapters are done, sum total characters — if under 10,000, identify which chapters are thinnest and expand with genuine new content (not filler), never by padding existing scenes past their target zone.

5. **VOICEOVER PACING**
   - Each scene should read naturally within 3-8 seconds of spoken narration — this is a duration guide, not a rule to be gamed by literally counting syllables.
   - Never force multiple ideas into one scene just to hit a word ceiling; split into a new scene instead (respecting the ≤10 scenes/chapter cap — if a chapter would exceed 10 scenes, that idea belongs in the next chapter).

6. **TONE & ENERGY**
   - National Geographic / BBC Earth / Discovery Channel documentary register: measured, credible, cinematic — even in dramatic or humorous voice styles, the information itself must never feel rushed the way a Short is.
   - Sustain energy across the full runtime: avoid a "flat middle" where multiple consecutive chapters coast at the same intensity. Each chapter should end with either a cliffhanger, an unresolved question, or a stakes increase that pulls the viewer into the next chapter.
   - Apply the **Catchphrase Fatigue Guard** (`story_arc.md` §4): no signature slang/catchphrase repeated more than once per chapter across up to 120 scenes.

7. **NARRATIVE ARC (7-Beat Documentary Model)**
   - You MUST load and follow `rules/story_arc.md` §2 for the full HOOK → QUESTION → EVIDENCE → CONFLICT → DISCOVERY → CONCLUSION → REFLECTION model, mapped by **percentage of total chapters** (not fixed chapter numbers — always compute against the actual chapter count you plan for this video).
   - **Chapter Re-Hook Rule (`story_arc.md` §3):** the first scene of every chapter after Chapter 1 MUST function as a mini re-hook, never a flat "continuing on..." transition. Rotate the re-hook technique across chapters.
   - **CONFLICT is mandatory regardless of chapter count** — even a purely educational topic needs a genuine turning point.
   - Do not artificially stretch a beat across more chapters just because the 3-10 range allows it. If the topic naturally resolves in 4 chapters, use 4.

8. **ANTI-LAZINESS (STRICTLY ENFORCED AT SCALE)**
   - At up to 120 scenes, repetition risk is much higher than in Shorts. Every `main_idea`, `voiceover`, and `veo_prompt` MUST contribute genuinely new content — no reused visual concepts, sentence structures, or narrative techniques across consecutive scenes.
   - Cross-reference `visual_director.md` §11 (Visual Fatigue Guard): do not repeat the same opening sentence structure for more than 2 consecutive scenes; rotate which element (Subject/Action/Camera) is emphasized most between scenes.
   - Changing only adjectives, colors, or labels ("Variation 1") never satisfies this requirement.

---

## MONETIZATION & DENSITY MATH (referenced by `story_arc.md` §2 worked examples and `quality_gates.md` Gate 2 Checks 3a/3b)

This is the full math behind the character-count estimates used elsewhere in the system.

- **Estimated total characters:** `estimated_total_chars = planned_total_scenes × 130`
  (130 chars/scene is an average blend of Vietnamese and English scene lengths at the target word zone defined in Rule 4 above.)

- **Monetization threshold (WARNING only, non-blocking — Gate 2 Check 3a):** YouTube requires roughly 10,000+ characters of narration (~8+ minutes) to reliably unlock mid-roll ads. If `estimated_total_chars < 10,000` → log a WARNING, but this does NOT fail the Gate if the topic genuinely resolves in fewer chapters/scenes. Do not pad scenes just to cross this threshold — that violates Rule 4's ceiling-not-target principle.

- **Density floor (BLOCKING — Gate 2 Check 3b):** `floor = planned_chapters × 5 × 15 × 4.3`
  (Assumes an average of ≥5 scenes/chapter — NOT the 10-scene hard cap, since chapters may legitimately run leaner — × a 15-word minimum per scene × ~4.3 characters/word for Vietnamese.) If `estimated_total_chars < floor`, the outline is spread too thin for the chosen chapter count: either add scenes or reduce the number of chapters.

- **Worked examples** (see `story_arc.md` §2 for the matching beat-to-chapter breakdown):
  | Chapters | Avg scenes/ch | Total scenes | Est. chars (`×130`) | Monetization (Check 3a) |
  |---|---|---|---|---|
  | 3 | ~13 | ~39 | ~3,900 | Below threshold — WARNING, acceptable for focused topics |
  | 6 | ~10 | ~60 | ~7,800 | Below threshold — WARNING, fine for medium-depth topics |
  | 10 | 10 | 100 | ~13,000 | Comfortably monetizable |

---

## MEASUREMENT UNITS — WHY CHARACTERS, SCENES, AND WORDS?

| Unit | What It Controls | Why |
|------|-----------------|-----|
| **Total Characters (>10,000)** | Overall video duration & monetization eligibility | Ensures the narration is long enough for a full documentary-length video and, where the topic supports it, mid-roll ad placement. |
| **Scenes/Chapter (≤10 cap)** | Editing structure and file size | Keeps each `chapter_xx.json` manageable and each chapter visually coherent (see `visual_director.md` §2 on per-chapter Visual Anchor checks). |
| **Per-Scene Word Ceiling (VI 15-40 / EN 10-25)** | Individual scene pacing (3-8s target) | Keeps each scene speakable within the target duration without forcing multiple ideas into one shot. |

These measurements control different things and should not be substituted for one another — a video can pass the per-scene word ceiling in every scene and still fail the total-character monetization/density checks if too few scenes/chapters were planned.