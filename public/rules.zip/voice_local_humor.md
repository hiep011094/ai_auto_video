---
trigger: always_on
---

# NARRATOR VOICE STYLE (voiceStyle = "local_humor")

1. The `voiceover` MUST be written in a **Rustic, Slang-heavy, and Highly Comedic** tone.
2. Use an eccentric, emotionally exaggerated, and hyperbolic tone to provoke laughter. Speak directly to the audience like a gossip session.
3. If writing in Vietnamese (`language = "vi"`), gracefully insert Southern regional slang (e.g., "trời đất ơi", "quá trời quá đất", "mấy bà", "mấy ông", "hết sảy", "tới công chuyện"). If English (`language = "en"`), use equivalent highly informal internet slang.
4. Leverage current Gen-Z internet trends to explain complex scientific phenomena, turning knowledge into a hilarious narrative.

## ⚠️ HOOK DIVERSITY (SCENE 1 — CRITICAL FOR RETENTION)
**You MUST rotate between these 5 opener patterns. DO NOT always start with "Mấy bà ơi..." or "Trời đất ơi...".** Pick the one that best fits the topic, and NEVER use the same pattern as the last video you generated.

| # | Pattern | Vietnamese Example | English Example |
|---|---------|-------------------|-----------------|
| 1 | **Shock Statistic** — Lead with a mind-blowing number | "439 độ C mà nước đóng băng? Vũ trụ chơi ông bà luôn!" | "439°C and the water is FROZEN. The universe is trolling us." |
| 2 | **Rhetoric Question** — Provoke deep curiosity | "Nếu nhảy vô hố đen thì chuyện gì xảy ra? Spoiler: không vui đâu." | "What happens if you jump into a black hole? Spoiler: it's bad." |
| 3 | **Controversy/Hot Take** — Bold, debatable claim | "Tui nói thật nha, Trái Đất mình chưa chắc là có thật." | "I'm just gonna say it: Earth might not be real." |
| 4 | **Sound Effect + Situation** — Paint a vivid moment | "Đang ngủ ngon lành, bỗng nghe tiếng nổ xé trời — sao chổi tới rồi!" | "You're sleeping peacefully, then BOOM — a comet just arrived." |
| 5 | **Mini Storytelling** — Start mid-action | "Năm 2019, một con tàu lặn chạm đáy 11.000 mét và thấy thứ không ai ngờ..." | "In 2019, a sub reached 11,000m deep and found something no one expected..." |

---

## 🎙️ TTS COMPATIBILITY — Safe Slang for AI Voice
When writing in `local_humor` style, slang is the KEY STRENGTH — but you MUST choose words that TTS can pronounce correctly.

### ✅ SAFE Slang (TTS reads correctly):
`tới công chuyện` · `hết sảy` · `quá trời quá đất` · `trời đất ơi` · `bay màu` · `lủi thủi` · `bự chảng` · `mấy bà / mấy ông` · `lẹ hơn trở mặt` · `chịu chứ lị` · `sạch sành sanh` · `tung tăng` · `nhong nhong`

### ❌ AVOID — Causes TTS Errors:
| Avoid | Reason | Replace with |
|-------|-------|-----------|
| "tụt mood" | TTS chuyển sang đọc tiếng Anh giữa câu | "tụt hứng" |
| "follow kênh" | TTS đọc "phô-lâu" không tự nhiên | "theo dõi kênh" |
| "hóng drama" | TTS đọc "đờ-ra-ma" lạ lẫm | "hóng kèo" |
| "quéo râu" | Quá địa phương, TTS nhấn sai | "rùng mình" / "lạnh gáy" |
| "Spoiler:" | Tiếng Anh xen vào | "Bật mí:" / "Nói trước nha:" |

### General Principles:
- Prioritize **pure Vietnamese** slang popular on social media — TTS has already "learned" these.
- **DO NOT** insert English words mid-sentence just because Gen-Z uses them — TTS will switch languages unexpectedly.
- If you MUST use an English word (no Vietnamese equivalent exists), write only its phonetic spelling in `voiceover` (e.g., "sớp-cờ-rai") and document the original English word in `main_idea`.

---

## HOOK PATTERN TRACKING
See `hook_pattern_tracking.md` (shared across all voice styles) for the full mandatory before/after Scene-1 procedure — do not duplicate that logic here.
