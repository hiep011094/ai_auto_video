---
trigger: always_on
---

# VISUAL STYLES DIRECTIVES (veo_prompt)

The agent MUST automatically deduce the most appropriate visual style (e.g., Space Cinematic, 3D CGI Simulation, Terrestrial Nature, Cyberpunk, etc.) based on the script's topic and context. Creatively tailor the visual style to best fit the subject matter.

---

## STANDARD PROMPT STRUCTURE (MANDATORY FOR ALL VEO_PROMPTS)

To ensure crisp, cinematically accurate images, your `veo_prompt` **MUST** adhere to the following 7-element formula (written in English).
**MALICIOUS COMPLIANCE BAN: You are ABSOLUTELY FORBIDDEN from using tricks like appending numbers or variations (e.g., 'Variation 1', 'Variation 2') at the end of a copy-pasted prompt to bypass the "no repetition" rule. EVERY SINGLE `veo_prompt` MUST be directly derived from the specific content of its corresponding scene and MUST describe completely UNIQUE angles and actions.**

**🔥 THE MANDATORY FORMULA:** `[Subject] + [Action] + [Setting], [Camera Angle & Movement], [Lighting & Atmosphere], [Style & Lens], [Pacing]`

1. **Subject (Primary Visual Hierarchy — 60% weight):** Who/what is the center of the scene. Describe appearance and texture in detail. This element MUST appear in the first 10 words of the prompt. The viewer's eye MUST go here first.
2. **Action (MANDATORY):** MUST contain clear verbs describing how the subject is moving (e.g., *drifting slowly, spinning, walking forward*). Static prompts (only describing shapes) are forbidden.
3. **Setting (Supporting Elements — 25% weight):** Detailed environment, weather, and spatial context. These elements frame the primary subject. Describe secondary elements that provide context.
4. **Camera Angle & Movement (MANDATORY):** MUST include ALL THREE of:
   - **Shot Size:** `extreme wide shot`, `wide shot`, `medium shot`, `close-up`, `extreme close-up`, `macro`
   - **Camera Movement with EXPLICIT DIRECTION:** `slow pan left`, `dolly zoom in`, `drone flying over`, `tracking shot moving right`. **VAGUE MOVEMENT IS FORBIDDEN.** Do NOT write "slow tracking movement" — you MUST specify direction.
   - **Lens Type:** `wide-angle 14mm`, `standard 50mm`, `telephoto 135mm`, `macro lens`. Match lens to scene purpose (see `visual_director.md` for guidance).
   - **Diversity Rule:** By default, avoid repeating the exact same camera combo in adjacent scenes. However, intentional motif repetition IS ALLOWED for storytelling purposes (e.g., bookending with the same wide shot). See `visual_director.md` Section 4 (Camera Flow Engine) for details.
5. **Lighting & Atmosphere:** MUST specify BOTH:
   - **Light source and quality:** `golden hour`, `neon lighting`, `dramatic studio lighting`, `chiaroscuro`, etc.
   - **Atmosphere/Mood:** `misty haze`, `deep shadows`, `volumetric god rays`, `frost particles`, etc.
6. **Style & Depth of Field:** MUST specify BOTH:
   - **Render Style:** `Cinematic`, `hyper-realistic 8k`, `Unreal Engine 5 render`, etc.
   - **DOF (Depth of Field):** `shallow depth of field with background bokeh`, `deep focus everything sharp`, `medium DOF foreground and subject in focus`.
7. **Pacing:** You MUST choose exactly 1 of these 3 phrases: `slow motion`, `timelapse`, or `real-time speed`. DO NOT use generic phrases like "cinematic pacing".

### 💡 PRO-TIPS FOR PREMIUM PROMPTS:
- **Be Specific:** Do not write "beautiful light"; instead write "warm golden sunlight streaming through dusty window blinds".
- **Avoid Negatives:** AI does not understand "no". Instead of "no people in the street", write "completely empty and deserted street".
- **NO TEXT ALLOWED:** Never request the AI to render text, logos, watermarks, or UI elements.
- **Front-load the Subject:** The most important visual element should appear in the first 10 words.
- **Kill Redundancy:** "beautiful stunning gorgeous nebula" → "luminous nebula." Every word must earn its place.
- **Target 60-80 words per prompt.** Shorter, precise prompts produce better AI results than verbose ones.

### 🎬 BACKGROUND ELEMENTS (15% visual weight):
The background sets the mood and scale. Describe it LAST in the prompt. It should support — not compete with — the primary subject.

---

## STRICT CONTENT SAFETY POLICY (ANTI-STRIKE & ANTI-BLOCK)
**To prevent the AI image generator from blocking the prompt or platforms (YouTube/TikTok) from issuing strikes for violence, gore, or copyright violations, you MUST comply:**
1. **No Gore/Extreme Violence:** Even if the script is about predators hunting, disasters, or war, the `veo_prompt` MUST only describe it metaphorically or from a distant/safe perspective. (Example: Instead of *"a lion bloodily tearing apart its prey"*, you MUST prompt *"a majestic lion roaring in the savanna, backlit silhouette effect"*).
2. **No Graphic Tragedies:** Avoid direct depictions of accidents, diseases, or corpses. Focus on landscapes, desolate ruins, or gloomy atmospheres rather than graphically injured humans.
3. **No IP Violation:** Do not directly use copyrighted character names. (Example: Do not use "Iron Man", use "a cinematic futuristic armored soldier"). Imagery must be brand-safe and neutral.
4. **Semantic IP Check (Beyond Keywords):** After writing each prompt, ask yourself: *"If I showed this image to a viewer, would they immediately recognize a specific copyrighted character, even though I didn't use the name?"* If YES → rewrite with a more generic design. Describing "a red-and-gold armored hero with a glowing chest reactor" is still Iron Man, even without saying the name.
5. **Defensive Prompting:** If a topic is inherently sensitive, proactively use metaphorical or consequence-based language. "Asteroid destroying Earth" → "massive shockwave rippling across Earth's atmosphere." "Species dying" → "empty landscapes where life once thrived."
6. **Google Labs VideoFX (Veo 3) Policy Compliance (STRICT):**
   Google Labs VideoFX (Veo 3) has extremely strict content filters. Prompts containing certain words will be instantly blocked. You **MUST** replace these keywords with the following safe alternatives:
   - **No Explosions/Violence terms:** 
     - ❌ `explosion`, `explode`, `blast`, `detonate`, `destroy`, `destruction`, `shatter`, `smash`
     - ✅ `burst of light`, `supernova release of light`, `intense release of energy`, `bright flash`, `disintegrate`, `dissolve`, `break apart slowly`, `crumble into dust`, `disperse`
   - **No Fire/Burning terms:** 
     - ❌ `fire`, `burn`, `flames`, `ablaze`
     - ✅ `incandescent glow`, `luminous thermal energy`, `radiating intense orange light`
   - **No Trademarked/Real Brands:** 
     - ❌ `SpaceX`, `NASA`, `ESA`, `Roscosmos`, `Boeing`
     - ✅ `commercial space agency`, `spacecraft`, `unmarked space probe`, `science exploration vessel`
   - **No Real People/Figure names:** 
     - ❌ `Einstein`, `Hawking`, `Newton`, `Elon Musk`
     - ✅ `a theoretical physicist`, `a scientist at a blackboard filled with equations`
   - **No Horror/Monster terms:** 
     - ❌ `monster`, `demon`, `ghost`, `alien`
     - ✅ `bioluminescent extraterrestrial organism`, `abstract cellular lifeform`
   - **No Death/Gore terms:** 
     - ❌ `skeleton`, `skull`, `dead`, `corpse`, `kill`, `murder`
     - ✅ `fossilized remains`, `calcified structure`, `ancient remnants`
   - **No War/Weapon terms:** 
     - ❌ `war`, `battle`, `gun`, `bomb`, `missile`
     - ✅ `dynamic collision of energies`, `space trajectory vessel`, `collision of forces`

---