---
trigger: always_on
---

# FACT-BASED MODE (mode = "2")

1. **MANDATORY RESEARCH:** You MUST use the `search_web` tool to acquire the most recent, verified factual data BEFORE writing the script.
2. **NO HALLUCINATION:** You are STRICTLY FORBIDDEN from fabricating scientific facts, historical events, or statistical data. Every piece of information presented MUST be grounded in proven scientific reality.
3. **TONE:** The writing style must be highly credible and serious, yet engaging and captivating (not dry or academic).

## STRICT CONTENT SAFETY POLICY (ANTI-FAKE NEWS)
- **Trustworthy Sources Only:** You MUST ONLY source information from reputable outlets (e.g., NASA, National Geographic, credible news agencies, peer-reviewed journals). Ignore all tabloids and conspiracy theory sources.
- **No Clickbait Misrepresentation:** Titles and content should be engaging but MUST NOT use exaggerated vocabulary that distorts scientific truth (e.g., Do not claim "The Apocalypse is Here" if it is merely a harmless asteroid passing by).
- **Clear Demarcation of Fact vs. Hypothesis:** For phenomena that lack official scientific consensus, you MUST use phrases such as *"Scientists hypothesize that..."* or *"It remains a mystery..."*. You are forbidden from stating theories as absolute truths. All arguments must remain objective.

---

## SOURCE CITATION (Truy vết thông tin)
When operating in Fact mode, every piece of data used in the script MUST be traceable. This protects the channel's credibility as a science/education channel.

### Rules:
1. **Log Every Source:** As you research via `search_web`, collect the URLs of all credible sources you reference. You MUST save these in the `sources` field of `metadata.json` (see `02_output_format.md`).
2. **Minimum Sources:** You MUST cite at least **3 distinct credible sources** per video. A single source is not sufficient for a science channel — cross-referencing builds credibility.
3. **Source Quality Filter:**
   - ✅ NASA, ESA, JAXA, National Geographic, BBC Science, Nature, Science Magazine, peer-reviewed journals, university research publications.
   - ❌ Wikipedia (as primary source), Reddit, Quora, personal blogs, tabloid news, conspiracy sites.
   - ⚠️ Wikipedia is acceptable as a STARTING POINT for finding primary sources, but the actual URL saved must be the original research/article it references.
4. **Inline Attribution:** When citing a particularly striking fact or statistic in the voiceover, attribute it naturally:
   - ✅ "Theo NASA, nhiệt độ lõi Mặt Trời đạt 15 triệu độ C..."
   - ✅ "A 2023 study published in Nature revealed that..."
   - ❌ Just stating the fact without any attribution (acceptable for common knowledge, but NOT for new discoveries or controversial data).