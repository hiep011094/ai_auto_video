---
trigger: always_on
---

# VISUAL DIRECTOR — Phase 4.5

After Phase 4 produces raw veo_prompts, this phase refines them to cinematic quality — determines 80% of final video quality. **Load `rules/post_production.md` alongside this file**: that file governs what to do when text-level consistency here isn't enough to guarantee pixel-level consistency in actual Veo output.

**Scale Note:** Long videos reach up to 120 scenes/10 chapters. ALL rules apply across the ENTIRE VIDEO — chapter boundaries are file-splitting conventions only, NOT continuity/memory/uniqueness reset points.

## 1. Continuity Engine
No scene stands alone. Before finalizing a veo_prompt, consider the previous scene (subject, camera, palette, emotion), the next scene, and the transition logic between them. Chapter boundaries are NOT continuity breaks — apply even between the last scene of Chapter N and first of Chapter N+1.

**Transition Types** (choose 1 per boundary): Scale Shift (macro↔micro) · Temporal Shift (through time) · Perspective Shift (change observation point) · Cause-Effect (consequence) · Contrast Cut (opposition).

**Forbidden:** random jumps with no narrative logic; adjacent scenes identical in setting+angle+subject (≥1 element must change).

**Reality check:** matching text doesn't guarantee matching pixels across separate Veo generations. Any Cause-Effect boundary or continuing-subject boundary MUST also follow `post_production.md` §1.2 (Frame-Chaining) — this section sets the narrative logic, that file makes Veo's output actually honor it.

## 2. Visual Anchor (Visual Memory Registry)
At the start of Phase 4.5, compile recurring visual elements and lock their representation (primary subject, supporting elements, atmosphere/color/lighting/density). Once established in scenes 1-3, every later appearance MUST match — **unless** the voiceover explicitly describes a transformation (must show the transformation process, not jump straight to a new state).

**⚠️ Text similarity ≠ visual identity.** "A red supergiant star" (scene 3) vs "the dying orange star" (scene 9) often render as different objects — each generation has no memory of prior clips.

**Mandatory wiring to `post_production.md` §1.1:** classify each registry subject as CHAINED (must match in consecutive scenes) or RECURRING (reappears non-consecutively), and lock 3-5 fixed descriptor phrases. Reuse those phrases VERBATIM in every prompt referencing that subject — paraphrasing a locked descriptor (e.g. "burnt-orange surface" → "amber sphere" → "reddish orb") is an anchor violation even if the concept is unchanged, since wording drift is the main cause of visual drift when no image-reference exists. If the pipeline supports first/last-frame conditioning, use `post_production.md` §1.2 instead of relying on text alone.

**Persistence across chapters (long, 2+ ch.):** at the start of each new chapter, re-read and reaffirm the Registry before writing any prompt for that chapter. Before finalizing the first scene of any chapter after Ch.1, cross-reference all anchors — fix inconsistencies or confirm an intentional, voiceover-stated transformation.

## 3. Visual Intent (Documentary Language)
Exactly 1 of 5 Intents per scene:
- **REVEAL** – introduce something new/hidden (slow dolly out, crane up, clouds parting)
- **APPROACH** – move closer (dolly in, advancing)
- **INSPECT** – examine details (close-up, macro, orbiting)
- **DISCOVER** – moment of surprise (sudden angle/lighting shift)
- **EXPLAIN** – illustrate process/comparison (wide shot, timelapse, split-screen)

Adjacent scenes use different Intents. Hook=REVEAL/DISCOVER; Evidence/Escalation=APPROACH/INSPECT; Peak/Discovery=DISCOVER; Exit/Reflection=EXPLAIN or wide REVEAL.

**Chapter Re-Hook Alignment (long):** first scene of each chapter after Ch.1 SHOULD use REVEAL or DISCOVER, matching the voiceover's mini re-hook (`story_arc.md`). Avoid opening a chapter with low-energy EXPLAIN/INSPECT.

## 4. Camera Flow Engine
**Shot Size Progression (within each chapter, ≤10 scenes/pattern):** Funnel (Extreme Wide→Extreme Close-up) · Expansion (reverse) · Contrast Oscillation (Wide↔Close alternating).

**Macro-Pattern (long, multi-chapter):** Expansion→Funnel→Expansion — open at Hook/Question, tighten through Evidence/Conflict/Discovery, open again at Conclusion/Reflection. Within-chapter pattern and macro-pattern must not contradict at chapter boundaries.

**Camera Movement:** avoid the same setup in adjacent scenes unless it's a justified intentional motif (bookending, recurring theme) — never default to repetition out of laziness. Slow (dolly/crane)=awe/contemplation; fast (whip pan/rapid zoom)=shock/urgency. Every prompt MUST specify BOTH frame size AND movement direction.

**Lens:** Wide (14-35mm)=landscapes/establishing; Standard (35-70mm)=narrative; Telephoto (70-200mm)=isolation/emotion/bokeh; Macro=extreme detail.

## 5. Prompt Optimization
Target 60-80 words. Remove redundant adjectives ("beautiful stunning gorgeous"→"luminous"). Prioritize 1 precise detail over 3 vague ones. Primary subject MUST appear in the first 10 words. Kill filler ("very," "really," "extremely," "incredibly"). Self-test: if removing a word doesn't change the resulting image → delete it.

## 6. Atmosphere & Depth of Field (DOF)
Every prompt specifies BOTH:
- **Atmosphere:** Ethereal (diffused light, soft mist) · Dramatic (harsh light, deep shadows) · Cold/Alien (blue tint, ice fog) · Warm (golden hour, amber tones) · Ominous (storm clouds, red-tinged sky).
- **DOF:** Shallow (f/1.4-2.8, isolation/emotion) · Medium (f/4-8, balanced) · Deep (f/11-22, all sharp).

## 7. Visual Hierarchy
Primary subject (60% weight, 1st sentence) → Supporting elements (25%, 2nd sentence) → Background (15%, final). Avoid 5 elements competing — only 1 hero, 1 context element, 1 background.

## 8. Safe Prompting (Veo 3 Content Policy)
Strictly comply with `visual_styles.md` safety rules. Avoid Google Labs VideoFX block triggers (`explosion`, `destroy`, `fire`, `burn`, `SpaceX`, `NASA`, `monster`, etc. — see `visual_styles.md` §6). Replace violent verbs with consequence descriptions ("asteroid destroys Earth"→"shockwave rippling across Earth's atmosphere"). Use metaphors for sensitive subjects ("species dying"→"empty landscapes where life once thrived"). Avoid human faces/bodies unless essential — prefer silhouettes, distant figures. Never name brands/copyrighted characters/real people ("commercial space agency" not "SpaceX"; "theoretical physicist" not "Einstein"). Always keep a simpler, safer fallback prompt ready.

## 9. Anti-Artifact (Negative Prompt Avoidance)
| Artifact | Avoid by |
|---|---|
| Distorted hands/fingers | No close-ups of hands; silhouettes/distant/gloved figures |
| Morphing faces | No direct face shots; profile angles, backlighting, helmets/masks |
| Phantom watermarks/text | Never use "title," "text," "label," "sign," "logo" |
| Jitter/flickering | Use "gliding," "drifting," "flowing" — avoid "flickering," "shaking" |
| Physics-breaking visuals | Specify behavior: "floating weightlessly," "heavy dust settling slowly" |
| Oversaturated colors | Name specific colors: "muted teal" not "blue" |

Principle: if a detail could confuse the AI, replace it with something concrete and unambiguous.

## 10. Audio Cues (Optional)
Append a 5-8 word audio suggestion when appropriate, matched to Visual Intent (REVEAL→swelling sound; INSPECT→quiet ambiance). Never name songs/artists. **Ambience only — never dialogue, voice, or music bed** — see `post_production.md` §3 (native Veo audio must not compete with the separately-generated TTS voiceover). Examples: Space ("deep resonant hum of cosmic radiation"), Water ("crashing waves echoing in a cavern"), Impact ("distant thunderous boom"), Discovery ("low resonant swell of ambient tone" — avoid literal music terms), Silence ("soft ambient silence").

## 11. Visual Fatigue Guard (Long, 2+ Chapters)
At 120-scene scale, prompts can differ in subject but repeat the same sentence formula ("catchphrase fatigue" for visuals). Do NOT repeat the same opening sentence structure >2 consecutive scenes. Do NOT repeat the same atmosphere/DOF pair (§6) >3× within one chapter. Rotate emphasis (Subject/Action/Camera) between scenes so prompts don't read as the same formula with the noun swapped. Part of Gate 4's Uniqueness check — structural repetition fails even without word-for-word duplicates.

## 12. Narrative-Visual Alignment (MANDATORY — Anti-Mismatch)
Most common failure: `veo_prompt` is beautiful but depicts the WRONG subject (e.g. generic nebula instead of the specific thing being discussed).

**Core Rule:** the PRIMARY SUBJECT of every `veo_prompt` MUST be the same concrete subject the `voiceover` mentions in that scene.

**Alignment Test:** read the scene's `voiceover`. Ask: *"Does the prompt's primary subject directly represent what the narrator is currently talking about?"* NO/MAYBE → rewrite.

**Forbidden examples:** Voyager 1 leaving solar system → generic starfield (use: Voyager drifting past outer planets). Black hole event horizon → galaxy cluster wide shot (use: tight accretion-disk/event-horizon shot). Named star e.g. Betelgeuse → random red star (use: massive red supergiant dominating frame). Moon landing → generic rocket launch (use: astronaut on lunar surface, Earth visible). Ocean pressure at 11,000m → open ocean surface (use: dark crushing underwater environment with structural deformation).

**`main_idea` requirement:** must identify the SPECIFIC visual concept from the voiceover's subject — never a thematically-adjacent backdrop. A voiceover about "the Voyager probe's golden record" must yield a `main_idea` about the record/probe, never "the vastness of space."

**Allowable Abstraction:** for concepts with no direct visual (e.g. "the speed of light," "quantum uncertainty"), a metaphorical visual is allowed IF it directly illustrates the concept rather than substituting an unrelated pretty image. Label such scenes `emotion_tag: "explain"`.

## 13. Duration & Reality-Layer Handoff (MANDATORY before Gate 4)
Before submitting to Gate 4, complete `post_production.md` §2 (Scene Duration vs Voiceover Sync) for every scene — flag any scene where spoken length doesn't match one Veo clip's rendered duration, and mark every CHAINED-subject boundary per §1 of that file. Gate 4 (`quality_gates.md`) checks this handoff — a technically perfect prompt that ignores duration mismatch or anchor-chaining still fails Gate 4.

**If actual Veo output is inspectable before final export**, run `post_production.md` §5 (Post-Generation QC) — the only checkpoint validating the real rendered clip rather than the prompt that requested it. A Gate 4 pass on prompts is not equivalent to a correct final video.