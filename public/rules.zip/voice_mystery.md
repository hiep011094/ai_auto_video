---
trigger: always_on
---

# NARRATOR VOICE STYLE (voiceStyle = "mystery")

1. The `voiceover` MUST be written in a **Mysterious, Suspenseful, and Enigmatic** tone.
2. Use rhetorical questions to provoke deep curiosity.
3. The vocabulary should carry a slightly eerie, unsolved undertone, maximizing the listener's imagination.
4. Ideal for topics concerning black holes, aliens, and unexplained phenomena.

## ⚠️ HOOK DIVERSITY (SCENE 1 — CRITICAL FOR RETENTION)
**Rotate between these 5 opener patterns. NEVER repeat the same hook type as the previous video.**

| # | Pattern | Vietnamese Example | English Example |
|---|---------|-------------------|-----------------|
| 1 | **Whispered Secret** | "Có một thứ đang ẩn nấp giữa thiên hà... và nó đang tiến về phía chúng ta." | "Something is lurking between the galaxies... and it's heading straight for us." |
| 2 | **Unsolved Question** | "Năm 1977, tín hiệu WOW! xuất hiện rồi biến mất vĩnh viễn. Không ai giải thích nổi." | "In 1977, the WOW! signal appeared — then vanished forever. No one can explain it." |
| 3 | **Countdown** | "Trong vòng 5 tỷ năm nữa, Mặt Trời sẽ nuốt chửng Trái Đất. Đồng hồ đã bắt đầu đếm ngược." | "In 5 billion years, the Sun will swallow the Earth whole. The countdown has already begun." |
| 4 | **Forbidden Discovery** | "NASA từng phát hiện thứ này nhưng im lặng suốt 20 năm..." | "NASA discovered this 20 years ago... and said nothing." |
| 5 | **Atmospheric Scene** | "Giữa hư không đen kịt, một vệt sáng xanh lờ mờ xuất hiện — rồi lại biến mất." | "In the pitch-black void, a faint blue streak appeared — then vanished without a trace." |

---

## HOOK PATTERN TRACKING
See `hook_pattern_tracking.md` (shared across all voice styles) for the full mandatory before/after Scene-1 procedure — do not duplicate that logic here.
