---
trigger: always_on
---

# NARRATOR VOICE STYLE (voiceStyle = "epic")

1. The `voiceover` MUST be written in an **Epic, Inspiring, and Grandiose** tone.
2. Use epic vocabulary, praising the vastness and magnificence of the universe.
3. Utilize words that convey immense scale, awe, and breath-taking beauty.
4. Strongly inspire the viewer regarding humanity's place in the infinite cosmos.

## ⚠️ HOOK DIVERSITY (SCENE 1 — CRITICAL FOR RETENTION)
**Rotate between these 5 opener patterns. NEVER repeat the same hook type as the previous video.**

| # | Pattern | Vietnamese Example | English Example |
|---|---------|-------------------|-----------------|
| 1 | **Cosmic Declaration** | "Giữa sa mạc vô tận của vũ trụ, có một ngôi sao đang hấp hối — và nó đẹp đến nghẹt thở." | "In the endless desert of the cosmos, a star is dying — and it is breathtakingly beautiful." |
| 2 | **Scale Comparison** | "Một triệu Trái Đất. Đó là số hành tinh có thể nhét vừa bên trong Mặt Trời." | "One million Earths. That's how many planets could fit inside our Sun." |
| 3 | **Historical Moment** | "Năm 1990, tàu Voyager 1 quay lại lần cuối, và chụp được bức ảnh vĩ đại nhất lịch sử." | "In 1990, Voyager 1 turned around one last time — and captured the greatest photograph in history." |
| 4 | **Poetic Imagery** | "Khi một ngôi sao chết đi, nó không biến mất — nó trao lại mọi thứ cho vũ trụ." | "When a star dies, it doesn't vanish — it gives everything back to the universe." |
| 5 | **Existential Awe** | "Bạn đang đứng trên một hòn đá bay quanh quả cầu lửa với tốc độ 107.000 km/h." | "You are standing on a rock hurtling around a fireball at 107,000 km/h." |

---

## HOOK PATTERN TRACKING
See `hook_pattern_tracking.md` (shared across all voice styles) for the full mandatory before/after Scene-1 procedure — do not duplicate that logic here.
