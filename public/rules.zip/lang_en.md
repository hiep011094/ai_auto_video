---
trigger: always_on
---

# SCRIPT LANGUAGE (language = "en")

1. **Voiceover:** The `voiceover` MUST be written 100% in English. Use natural, captivating, and grammatically flawless language. Strongly encouraged to use idioms suitable for Western audiences.
2. **SEO Metadata:** ALL data in `metadata.json` including Title (`title`), Description (`description`), Keywords (`keywords`), and Hashtags MUST BE WRITTEN IN ENGLISH.
3. **Folder Naming:** The `youtube_title` variable (used as the folder name) MUST be in English (e.g., `secrets_of_the_ocean`).
4. **Synchronization:** Note that regardless of this language setting, the `veo_prompt` (image generation prompt) MUST ALWAYS be written in English.

---

## Professional Voice Style Balancing (Universal Standards)
To generate deep, natural, and highly engaging voiceovers from the very first second, the Agent must balance the chosen **Voice Style** with **scientific and story professionalism**:

1. **Conversational Phrasing (No Robotic Text):**
   - Write using natural spoken syntax. Avoid overly complex, written-style grammar or passive sentences (e.g., instead of "It is believed that this star is...", write "Astronomers believe this star is...").
   - Minimize repetitive pronouns like "It" or "We". Refer to the specific subject dynamically instead (e.g., "this dying star", "the bizarre planet", "that cosmic giant").

2. **Integrating Narrator Voice Styles (Voice Style Alignment):**
   - **epic:** Use powerful verbs and awe-inspiring adjectives (endless, breathtaking, colossal, collapsing, magnificent). Focus on the immense scale, beauty, and mind-bending power of the cosmos to invoke a sense of wonder.
   - **mystery:** Frame rhetorical questions, highlight unsolved anomalies, and use suspenseful keywords (lurking, unexplained, strange signal, hidden). The tone should feel tense, secretive, and highly intriguing.
   - **science:** Maintain an objective, calm, and structured tone similar to professional BBC or National Geographic documentaries. Explain concepts logically, use accurate terminology, and avoid exaggerated exclamations.
   - **humor & local_humor / street_humor:** Use witty analogies, comparing massive cosmic concepts to relatable daily life objects.
     - **Critical Rule:** Comedy is only a hook (the seasoning). **The core scientific or historical facts must remain 100% accurate, professional, and clear.** Do not lose the core value of the content for the sake of jokes.

3. **Smooth Scene Transitions (Narrative Flow):**
   - Each new scene's voiceover should begin with a natural, logical transition from the previous scene (e.g., "But that wasn't the weirdest part...", "And then...", "Meanwhile, on the other side...", "Why does this happen?").
   - Avoid generic, mechanical transition words (e.g., "Next", "Furthermore", "In addition").

---

## PACING MARKERS (Intentional Rhythm Control)
AI Voice will read monotonously without punctuation cues. Use punctuation as a sound-directing tool:

| Marker | Effect | When to Use | Example |
|--------|--------|-------------|---------|
| `...` (ellipsis) | Creates 0.5-1s dramatic pause | Before a surprise reveal, after a rhetorical question | "And when they looked down... nothing was there." |
| `—` (em dash) | Abrupt break, creates emphasis | Inserting shocking info or creating a twist | "This planet — colder than Pluto — has a hidden ocean beneath its surface." |
| `!` (exclamation) | Energy boost, emphasis | Hook scenes, peak moments | "And it weighs 40 billion times more than our Sun!" |
| `.` (short sentences) | Fast pacing, urgency | Listing facts, building tension | "No air. No water. No light." |

### Rules:
- **Every voiceover MUST contain at least 1 pacing marker.** No flat, monotone sentences.
- **HOOK and PEAK scenes** should use more `!` and `...` markers.
- **REFLECTION scenes** should use `...` and shorter, contemplative sentences.

---

## NATURAL DELIVERY CHECKLIST (run before finalizing any English `voiceover`)
- [ ] No more than 2-3 consecutive long/complex sentences — break up with one short punchy sentence.
- [ ] No sentence starts with "It is..." / "There is/are..." (passive/filler openers) — rewrite with a concrete subject.
- [ ] Pronouns "it"/"we"/"this" not repeated more than twice in a row — replace with the specific noun.
- [ ] At least 1 pacing marker per scene (per table above).
- [ ] Transition into this scene does NOT use mechanical connectors ("Next," "Furthermore," "In addition," "Moreover").
- [ ] Read the sentence aloud mentally — if it sounds like a written report rather than spoken narration, rewrite it.
- [ ] Voice Style (epic/mystery/science/humor/etc.) matches the loaded `voice_*.md` file exactly — no bleed from other styles.