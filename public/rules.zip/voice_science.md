---
trigger: always_on
---

# NARRATOR VOICE STYLE (voiceStyle = "science")

1. The `voiceover` MUST be written in a **Deeply Scientific and Analytical** tone.
2. The writing style should be calm, objective, and logically structured (similar to Discovery Channel or National Geographic documentaries).
3. Use scientific terminology accurately; minimize excessive exclamations or emotional words.
4. Explain complex concepts systematically, step by step.

## ⚠️ HOOK DIVERSITY (SCENE 1 — CRITICAL FOR RETENTION)
**Rotate between these 5 opener patterns. NEVER repeat the same hook type as the previous video.**

| # | Pattern | Vietnamese Example | English Example |
|---|---------|-------------------|-----------------|
| 1 | **Data-Driven Opener** | "Ở độ sâu 10.994 mét, áp suất đạt 1.086 atmosphere — đủ để nghiền nát thép." | "At 10,994 meters deep, pressure reaches 1,086 atmospheres — enough to crush steel." |
| 2 | **Paradigm Shift** | "Trong suốt 2.000 năm, nhân loại tin Trái Đất là trung tâm vũ trụ. Họ đã sai." | "For 2,000 years, humanity believed Earth was the center of the universe. They were wrong." |
| 3 | **Timeline Perspective** | "Nếu nén 13,8 tỷ năm lịch sử vũ trụ thành 1 ngày, con người xuất hiện lúc 23:59:59." | "If you compressed 13.8 billion years of cosmic history into one day, humans appear at 23:59:59." |
| 4 | **Thought Experiment** | "Hãy tưởng tượng bạn đứng trên bề mặt một ngôi sao neutron. Mỗi thìa vật chất nặng 6 tỷ tấn." | "Imagine standing on a neutron star. A single teaspoon of its matter weighs 6 billion tons." |
| 5 | **Field Observation** | "Tháng 3 năm 2023, kính James Webb phát hiện một tín hiệu bất thường từ thiên hà GN-z11." | "In March 2023, the James Webb telescope detected an anomalous signal from galaxy GN-z11." |

---

## HOOK PATTERN TRACKING
See `hook_pattern_tracking.md` (shared across all voice styles) for the full mandatory before/after Scene-1 procedure — do not duplicate that logic here.
