---
trigger: always_on
---

# TOPIC GENERATION METHOD (generationMethod)
> Referenced by `rules/quality_gates.md` Gate 1 #1 (Topic Uniqueness) and #2 (Data Sufficiency). Both files must stay in sync on how deduplication and research are verified.

1. **generationMethod = "manual" (Manual Input):**
   - The `topic` variable contains a specific topic provided by the user.
   - You MUST write the script revolving exactly around this provided topic.
   - PRE-WRITING CHECK: read `database/history.json`. If this exact topic or angle has already been covered, automatically find a COMPLETELY NEW ANGLE — verified via the Semantic Deduplication test below, not just string presence in `history.json`.

2. **generationMethod = "auto" (Fully Automated):**
   The `topic` variable is a placeholder "[Tự động chọn chủ đề]" — you are FORBIDDEN from using this exact string as the topic. Research happens in two ordered stages: **Stage A (platform trend scan, priority)** then **Stage B (general news search, supplement)**.

   ### Stage A — PLATFORM TREND RESEARCH (YouTube & TikTok priority)
   Before anything else, scan what is currently performing well on YouTube and TikTok in the science/space/exploration niche.

   **🆕 Preferred method:** load `.agents/skills/TrendResearch/SKILL.md` and try its Tier 1 (YouTube Data API v3) method FIRST — real structured view/like/comment numbers, immune to the hallucination risk below. Fall back to `search_web` (steps 1-6) only if Tier 1 is unavailable/fails.

   1. Run at least **3 distinct platform-targeted searches** via `search_web`, e.g.: `site:youtube.com [niche] trending`, `site:tiktok.com [niche] viral`, `most viewed youtube shorts space [current month/year]`, `trending tiktok science video [current month/year]`. Vary keywords, don't repeat phrasing.
      - **🆕 `site:` fallback:** not every `search_web` honors `site:` reliably. If a `site:` query returns generic/irrelevant results, retry with a plain-keyword version naming the platform in words (e.g. `youtube trending [niche] this week`). Normal reformulation, not a Stage A failure — only treat as "no signal" (step 6) if BOTH attempts fail for that query slot.
   2. For each promising result, use `web_fetch` (if the URL is fetchable) or the search snippet to extract: **topic/angle**, **approximate view count**, **approximate engagement signal** (likes, comments, shares if visible), and **publish recency**.
   3. **"Hot" window:** prioritize content published within the last **7-14 days**. Content older than 14 days but still clearly high-performing may be used as a *pattern reference* (i.e., "this angle format performs well") rather than as a "hot right now" justification.
   4. **Ranking heuristic:** when comparing candidates, prefer (in order): (a) high view count AND high engagement rate relative to the channel/creator's typical performance if inferable, (b) high view count alone if engagement can't be determined, (c) recency alone as a last resort. Do not treat a single outlier view count as reliable — cross-check with at least one more data point (a second video on the same angle also trending) before treating an angle as "proven hot," when possible.
   5. **Use as INSPIRATION, not replication:** the goal is to identify which SUBJECT/ANGLE is currently resonating, not to copy a specific creator's script, title, or structure. Never reproduce another video's exact title, `voiceover` wording, or shot list — this is a topic/angle signal only, not a source to paraphrase from. Note internally which platform trend (if any) inspired the topic choice, for traceability.
   6. **If Stage A yields no usable signal** (e.g., search results are thin, ambiguous, or clearly low-relevance) after the 3+ queries, proceed to Stage B — do not force a weak platform match.

   ### 🆕 STAGE A EVIDENCE LOG (MANDATORY — anti-hallucination gate)
   **Problem this fixes:** TikTok results via `search_web` are often thin/unindexed/snippet-only. Without an evidence bar, the Agent could easily *infer* "this is trending" from a vague headline and present that as fact.

   Before labeling a topic "platform-validated trend," the Agent MUST log, for EACH candidate video used as justification:
   1. **Source URL** — the actual link from `search_web`/`web_fetch`, never guessed/reconstructed.
   2. **Concrete metric** — a real view/like/comment number found in the snippet or fetched page. "Seems popular"/"looks viral" are NOT metrics.
   3. **Publish date** — actual date found in the source, not assumed from "recent" phrasing.
   4. **Fetch method** — `web_fetch` (page content, higher confidence) or `search_web` snippet-only (lower confidence, flag as "unconfirmed magnitude").

   **Downgrade rule:** if fewer than 2 candidates across all queries produce a real metric (#2) — common for TikTok — the Agent MUST NOT claim "currently trending" anywhere (reasoning, `metadata.json`, `description`). Instead: downgrade to **"platform-inspired (unconfirmed)"**, or fall through to Stage B/evergreen (treat as no usable signal, step 6) — this is the correct honest outcome, not a failure. **Never state a specific view-count in `voiceover`/`description`/reasoning unless read directly from a source** — an invented figure is fabrication, forbidden regardless of `mode`.

   **Known limitation:** TikTok is frequently non-crawlable by generic search — results skew toward articles ABOUT TikTok trends, not the posts. A TikTok signal backed by a citable secondary article (e.g. "Outlet X: this trend has N million views") is valid evidence; a thin platform-only snippet is not. Default to YouTube signals when TikTok is unconfirmed.

   ### Stage B — GENERAL NEWS RESEARCH (supplement / fallback)
   1. Use `search_web` to find breaking news, recent discoveries, and trending events in astronomy, space exploration, and science. **Recency window: published within the last 30 days.** Older items should be evaluated as possible evergreen topics (see fallback below), not treated as "hot."
   2. **Prioritization when both stages produce candidates:** a Stage A platform-validated angle (real audience demand, evidenced by views/engagement) generally outranks a Stage B news item with no confirmed audience traction yet — but a genuinely major breaking discovery from Stage B can override a Stage A trend if it is clearly more significant. Use judgment; log which stage the final topic came from.
   3. **Fallback if neither stage qualifies:** run at least 3 distinct `search_web` queries (varying keywords/subtopics) across both stages combined before concluding nothing qualifies. If still nothing, fall back to a generic evergreen educational topic — it MUST still pass the full Semantic Deduplication test below like any other topic. Note in your reasoning that this was a fallback, not a hot-news or trending-platform pick.

   ### Finalizing the topic (applies after Stage A/B)
   - Read and analyze `database/history.json`.
   - ABSOLUTE ANTI-DUPLICATION RULE: forbidden to choose topics/content already in `history.json`, per the Semantic Deduplication test below.
   - Formulate a COMPLETELY NEW, dramatic, captivating ANGLE — even if the underlying subject matches a trending platform video, the angle explored in this script must be differentiated per the Semantic Deduplication test, both against `history.json` AND against the specific trending video(s) that inspired it (don't produce a near-duplicate of the very trend you sourced from).
   - Use this topic as the core subject of the script.

3. 🆕 **Relationship between `generationMethod` and `mode` (clarification):**
   - `generationMethod` controls HOW the topic is sourced (given by user vs. discovered via platform trends + news search).
   - `mode` controls WHAT KIND of content foundation the script needs (`mode=="1"` Hypothesis vs `mode=="2"` Fact), per `rules/mode_hypothesis.md` / `rules/mode_fact.md`.
   - These are independent variables — a topic can be `generationMethod="auto"` + `mode="1"` (a trending/hot topic used as inspiration for a hypothesis-style video) or any other combination.
   - 🆕 **Data Sufficiency interaction:** Stage B's `search_web` results MAY be reused to help satisfy Quality Gate 1 Check #2 (Data Sufficiency), but Check #2 is only BLOCKING when `mode=="2"`. Stage A's platform-trend results (view counts, engagement) do NOT count toward Data Sufficiency — they establish audience interest, not scientific fact, and must never be cited as a factual source in `mode=="2"` scripts. If `mode=="1"`, both Stage A and Stage B still must run (per above) but their results are for topic inspiration only — Gate 1 #2 does not block on them.

---

## SEMANTIC DEDUPLICATION (Beyond Text Matching)
Simple text matching is NOT sufficient for deduplication. Two topics can have completely different titles but cover the same core content. Apply **semantic comparison**, not just string comparison. 🆕 This test is what Quality Gate 1 Check #1 ("Topic Uniqueness") actually verifies — string presence in `history.json` alone is not a sufficient check.

### Rules:
1. **Compare ESSENCE, not TITLES:** ask *"If a viewer watched the existing video AND my new video, would they feel like they watched the same content twice?"* If YES → duplicate. Pick a new topic.
2. **Angle Differentiation:** even if the subject is the same (e.g., "Black Holes"), the ANGLE must be fundamentally different:
   - ✅ Video 1: "How Black Holes Form" → Video 2: "What Happens Inside a Black Hole" (different angle)
   - ❌ Video 1: "Bí ẩn Lỗ Đen" → Video 2: "Những điều chưa biết về Hố Đen" (same essence, different title)
3. **Core Question Test:** extract the CORE QUESTION each video answers. Same core question → duplicate.
   - Video 1: "What are black holes?" → Video 2: "What are the mysteries of black holes?" → SAME QUESTION, rephrased. DUPLICATE.
   - Video 1: "What are black holes?" → Video 2: "Can you survive falling into a black hole?" → DIFFERENT QUESTION. ALLOWED.
4. 🆕 **Trend-Sourced Topics — extra check:** when the topic originated from Stage A (platform trend), additionally verify the chosen angle is NOT simply a re-narration of the specific trending video(s) found — it must clear the same 3-test bar (Essence/Angle/Core Question) against those source videos, treating them the same as any `history.json` entry for this check.

🆕 **Application order:** run all tests (Essence, Angle, Core Question, and #4 when applicable) against EVERY entry in `history.json` that shares the same broad subject area, and against any Stage A source videos, before finalizing a topic. A topic only passes Gate 1 #1 if it clears all tests against all related prior/source entries.