---
trigger: always_on
---

# CRAFT DRAMATURGY — PROFESSIONAL SCREENWRITING STANDARDS (15+ YEAR SHOWRUNNER LEVEL)

Engineering rules (`story_arc.md` beat %, `quality_gates.md` technical checks) control structure and safety, but they do NOT guarantee craft. This file encodes the judgment calls a veteran screenwriter/director makes that cannot be reduced to a percentage or a word count.

**Load this file together with `story_arc.md` during Phase 2 (outline). Keep it active through Phase 3 (scripting).**

---

## 1. THE DRAMATIC QUESTION ENGINE
Every script is driven by exactly ONE Central Dramatic Question (CDQ) — not a topic, a QUESTION with stakes.
- ❌ Topic (too weak): "Black holes are amazing."
- ✅ CDQ: "What actually happens to your body the instant you cross the event horizon?"

**During Step 2.2 (outline), state the CDQ explicitly** (internal planning note — not exported to JSON).

Rules:
- The CDQ must be answerable, but the answer must NOT be guessable from the hook alone. If a viewer can predict the payoff right after Scene 1, the CDQ is too weak — sharpen the angle.
- The PEAK/DISCOVERY beat MUST directly resolve the CDQ. If the payoff answers a *different* question than the one the hook raised, that's a Bait-and-Switch failure — rewrite.
- Do NOT resolve the CDQ early (before PEAK/DISCOVERY). Partial clues are fine (that's ESCALATION/EVIDENCE); full resolution before its beat is not.
- Secondary micro-questions may be raised and resolved mid-script, but must never eclipse the CDQ.

---

## 2. NARRATOR POV SHEET (define before Phase 3 scripting begins)
Before writing any `voiceover`, define internally (1-2 sentences, not exported to JSON):
- What does this narrator genuinely **believe** about the topic? (e.g., "thinks this is one of the most underrated dangers in the solar system")
- What does this narrator find most **surprising or absurd** about it?

This POV must stay constant across every scene. `voice_*.md` governs WORD CHOICE (epic/mystery/humor/etc.); the Narrator POV Sheet governs the underlying ATTITUDE — so the same fact always lands with the same emotional signature, instead of the narrator sounding like a different person scene to scene.

---

## 3. ESCALATION BY STAKES (not escalation by info-stacking)
"Each scene adds new information" (per `video_short.md`/`video_long.md`) is necessary but NOT sufficient for real escalation. During ESCALATION/EVIDENCE/CONFLICT beats, every scene must raise the stakes along at least ONE of these 3 axes versus the previous scene:

1. **Threat/Consequence** — what's at risk gets bigger or more concrete.
2. **Proximity/Personalization** — the abstract becomes something that could happen to YOU, or to something relatable.
3. **Paradox/Reversal** — new information contradicts or subverts what the viewer just assumed.

**Self-check per escalation scene:** *"Does this scene only add a new FACT, or does it also raise the STAKES along one of the 3 axes above?"* A run of scenes that only stack facts without raising stakes reads like a Wikipedia list, not a story — this is a FAIL even if every scene individually satisfies the info-density rule.

---

## 4. SHOW, DON'T TELL
Forbidden pattern: stating the intended emotional reaction directly instead of engineering the scene to produce it.
- ❌ Telling: "Điều này thật đáng sợ." / "This is absolutely terrifying." *(no concrete image/consequence attached)*
- ✅ Showing: describe the concrete detail that makes it terrifying, and let the fact carry the emotion. "Ở độ sâu đó, áp suất đủ nghiền nát một chiếc xe tăng như lon nước ngọt." / "At that depth, the pressure would crush a tank like a soda can."

**Rule:** any sentence whose sole content is naming an emotion/judgment ("shocking", "amazing", "scary", "đáng sợ", "kinh ngạc") with no concrete image, number, or consequence in the SAME sentence is a FAIL. Emotion words are allowed only as seasoning on top of a concrete detail, never as a replacement for one.

---

## 5. CALLBACK & FORESHADOWING
A callback is a DELIBERATE repetition of an earlier detail/image/phrase, **recontextualized to land with new meaning**. This differs from redundancy (which Gate 3 "Progression" already bans) — a correctly-executed callback is not a FAIL, it is a required craft technique.

- **Short videos:** a callback is OPTIONAL but encouraged — e.g., EXIT beat may echo the HOOK's opening image with a twist.
- **Long videos (2+ chapters):** the REFLECTION beat (final chapter) MUST callback at least ONE specific detail, image, or phrase established in the HOOK (first chapter). This is what makes the ending feel earned rather than just "the video is over."
- **Distinguishing a valid callback from a redundancy FAIL:** a callback recontextualizes — "remember that number from the hook? here's what it actually means now that you know the full story." Simply repeating the same sentence/fact with no new layer of meaning is still a redundancy FAIL.

---

## 6. SUBTEXT CHECK (for reflective/philosophical scenes)
REFLECTION/EXIT beats should imply meaning through the specific image chosen, not state a generic moral directly.
- ❌ Generic moral: "Vũ trụ thật kỳ diệu và chúng ta nên trân trọng cuộc sống." *(could close literally any science video — sign of weak, generic writing)*
- ✅ Specific implication: an ending that ties the closing image back to the CDQ and this topic's specific angle, so it could not be copy-pasted onto a different video.

**Self-check:** *"Could this closing line be pasted onto a completely different topic's video with no edits and still make sense?"* If YES → too generic, rewrite to be specific to this CDQ.

---

## HOW THIS INTERACTS WITH EXISTING RULES
- This file does NOT override `story_arc.md`'s beat percentages, `video_short.md`/`video_long.md`'s length rules, or `lang_vi.md`/`lang_en.md`'s technical formatting — it governs CRAFT QUALITY *within* those structural constraints.
- Priority when in conflict: `SAFETY > ACCURACY > CONTINUITY > BEAUTY` (per `01_workflow_router.md`). Techniques in this file fall under BEAUTY/CONTINUITY — they NEVER override a SAFETY or ACCURACY rule (e.g., never sacrifice `mode_fact.md`'s no-hallucination rule just to manufacture a better callback).
- Verified at **Quality Gate 2** (CDQ + Narrator POV defined) and **Quality Gate 3** (Escalation-by-Stakes, Show-Don't-Tell, Callback, Subtext) — see `quality_gates.md`.