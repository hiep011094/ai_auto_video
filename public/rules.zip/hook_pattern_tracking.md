---
trigger: always_on
---

# HOOK PATTERN TRACKING (SHARED — applies to ALL voiceStyle values)
> Single source of truth. Every `voice_*.md` file (epic, humor, mystery, science, local_humor, street_humor) references this file instead of repeating its own copy. If this logic ever needs to change, edit ONLY this file.

Before choosing a hook pattern for Scene 1:
1. Read the `last_hook_pattern` field from the most recent `history.json` entry that shares the SAME `voiceStyle` as the current video (if present).
2. Do NOT reuse that exact pattern number (1-5, per the active `voice_*.md` file's own table). If no prior data exists for this `voiceStyle`, choose freely.
3. `street_humor` has one additional constraint on top of this shared rule: never use pattern #1 twice within the last 3 videos of that style (see `voice_street_humor.md` §7).

After finalizing the script:
4. Record the pattern number used (1-5) into this video's `last_hook_pattern` field for `history.json` (schema in `02_output_format.md`).

This applies uniformly across all voice styles — there is no style-specific variation of this mechanism beyond the street_humor addendum in step 3.
