---
trigger: always_on
---

# POST-PRODUCTION PROTOCOL (Phase 4.75 — Veo 3.1 Reality Layer)
> Loaded together with `visual_director.md` during Phase 4.5, and again at Phase 5 packaging.
> **Why this file exists:** Everything in `visual_director.md` and `visual_styles.md` optimizes the *prompt*. This file governs the *actual generated clips* — the gap between "a great prompt" and "a video that cuts together as one continuous piece." Priority tier: CONTINUITY (per `01_workflow_router.md`'s SAFETY > ACCURACY > CONTINUITY > BEAUTY).

---

## 1. CROSS-CLIP CONTINUITY — REFERENCE IMAGE & FRAME-CHAINING
**Core problem:** Veo has no memory between generations. Two `veo_prompt`s that both say "a red supergiant star, dying, orange-red surface" will NOT reliably produce the same-looking star — text similarity does not guarantee visual identity. `visual_director.md` §2 (Visual Anchor) locks the *description*; this section locks the *actual pixels*.

### 1.1 Reference Image Assignment (mandatory for recurring subjects)
During Phase 4.5, after compiling the Visual Anchor Registry, classify every recurring subject (a specific star, planet, probe, character silhouette, location) as one of:
- **CHAINED** — subject must look visually identical across 2+ consecutive scenes.
- **RECURRING** — subject reappears later, non-consecutively (e.g., HOOK's opening image recalled in REFLECTION).

For every CHAINED or RECURRING subject, add a `reference_note` (internal planning note, not exported to JSON unless the pipeline supports an image-reference field) specifying:
1. Which scene FIRST establishes the definitive look of this subject.
2. Every later scene number that must match it.
3. The 3-5 fixed visual descriptors that must NOT drift (e.g., "burnt-orange surface, three visible solar flares on the left limb, slightly ovoid shape") — repeat these EXACT descriptor phrases verbatim in every `veo_prompt` referencing that subject, rather than paraphrasing them differently each time. Paraphrasing ("orange star" → "amber sphere" → "reddish orb") is a common silent failure mode — text drift causes visual drift.

### 1.2 First-Frame/Last-Frame Chaining (mandatory for CHAINED subjects, long videos 2+ chapters, and any Scale/Temporal/Perspective Shift transition per `visual_director.md` §1)
If the generation pipeline supports image-to-video or first-frame conditioning:
- The LAST frame of a clip whose transition type is "Cause-Effect" or where the same physical subject continues into the next scene MUST be extracted and supplied as the FIRST-frame reference for the next generation, instead of relying on text description alone.
- If the pipeline does NOT support frame conditioning, this becomes a HARD REQUIREMENT to flag explicitly to the user/editor: list every scene boundary where frame-chaining was needed but unavailable, so a human editor knows exactly where a crossfade or cutaway will be needed to mask the visual mismatch (see §3).

### 1.3 Degradation Fallback
If reference-image conditioning is unavailable AND the subject is CHAINED across scenes: prefer a CUTAWAY structure (insert a neutral/establishing shot between the two subject appearances) over two consecutive direct shots of the same subject — a visible mismatch is far more jarring in a direct cut than across a cutaway.

---

## 2. SCENE DURATION vs VOICEOVER SYNC
**Core problem:** Veo 3.1 generates clips in fixed/near-fixed durations (model- and setting-dependent, commonly ~8s per generation). Voiceover sentences from Phase 3 do not naturally land on exact multiples of that duration — a sentence may read in 5.3s or 9.4s.

### Rules:
1. **Before finalizing Phase 4 prompts**, estimate each scene's spoken duration (rule of thumb: ~2.5 Vietnamese words/second or ~2.3 English words/second at the target narration pace defined in `voice_*.md`).
2. **If estimated duration < clip duration** (clip will run longer than the line): the `veo_prompt`'s Pacing element (`visual_styles.md` element 7) MUST be set to sustain visual interest for the full clip without needing new narration — e.g., prefer `slow motion` or a continuing camera move (`dolly in`, `slow pan`) over an action that visually "completes" early and then sits static.
3. **If estimated duration > clip duration** (line is longer than one clip can cover): the scene MUST be split into two sequential `veo_prompt`s under the SAME `voiceover` scene, sharing the same reference/anchor per §1, with the camera/action explicitly progressing (not repeating) between the two — e.g., Clip A = wide establishing move, Clip B = continuation/push-in on the same subject. Flag this scene in the output notes as a "2-clip scene" so the editor knows to render and concatenate both before the voiceover cut point.
4. **Never silently stretch or shrink `veo_prompt` Pacing just to force a duration match** if it damages Visual Intent (`visual_director.md` §3) — apply §1.3's cutaway fallback instead.

---

## 3. AUDIO LAYERING PROTOCOL
**Core problem:** Veo 3.1 can natively generate ambient sound, foley, and in some modes dialogue/music. This system's `voiceover` is produced separately via TTS. Left unmanaged, the two audio sources will overlap and clash on export.

### Rules:
1. **Default mode: Veo audio OFF / muted on render, or ambience-only.** When configuring each Veo generation, explicitly request "no dialogue, no voice, no narration" in the `veo_prompt`'s implicit expectations — the Audio Cue appended per `visual_director.md` §10 should describe AMBIENT texture only (wind, hum, distant rumble), never speech, music stings, or sound effects that would compete rhythmically with the voiceover's pacing markers (`lang_en.md`/`lang_vi.md` pacing tables).
2. **If the render pipeline cannot disable native audio:** note this explicitly in the Phase 5 packaging output so the editor knows to mute/duck the clip's native track under the voiceover during assembly, keeping it only as a low-level ambience bed (recommended: -18dB to -24dB relative to voiceover).
3. **Music:** this system does not generate a score. Do not describe music genres/instruments in `veo_prompt` audio cues (per `visual_director.md` §10, "never name specific songs or artists" — extend this to: never request a music bed at all, since it will not be mixable against a separately-added score without knowing key/tempo). Leave scoring to a dedicated post-production/editor decision outside this pipeline.

---

## 4. ASSEMBLY / EDIT NOTES (exported guidance, not enforced by Veo itself)
Phase 5 packaging MUST include a short internal `edit_notes` summary (can be appended as a top-level note in `metadata.json` under an optional `production_notes` field, or as a separate `edit_notes.md` in the project directory) covering:
1. **Transition map:** for each scene boundary, the Transition Type used (per `visual_director.md` §1) and whether it's a hard cut, crossfade, or requires a cutaway per §1.3 of this file.
2. **2-clip scenes:** list every scene split per §2.3, with instructions to concatenate before syncing to the voiceover.
3. **Color consistency risk:** flag any run of 3+ consecutive scenes sharing the same Atmosphere/Lighting keyword pair (per `visual_director.md` §6) as LOW risk, and any abrupt Atmosphere change between adjacent CHAINED-subject scenes as a risk requiring a color-match pass in the editor (e.g., a quick grade to unify white balance) since Veo does not guarantee consistent color science between separate generations even with identical prompt language.
4. **Frame-chaining gaps:** list every boundary flagged in §1.2 where chaining was required but unavailable.

This file does NOT perform actual video editing — it ensures the generation stage produces the information an editor (human or automated assembly script) needs to make the final cut seamless, and it flags every point of highest continuity risk instead of assuming text-level consistency equals visual consistency.

---

## 5. POST-GENERATION QC (run AFTER Veo returns actual clips, if the pipeline allows inspection)
Everything upstream (Gate 4 in `quality_gates.md`) validates the *prompt*, not the rendered output. If actual generated clips can be inspected before final export:
1. **Subject fidelity check:** does the rendered clip's primary subject match `main_idea` for that scene? (Veo frequently drifts from prompt intent, especially on abstract/metaphorical prompts per `visual_director.md` §12's "Allowable Abstraction.") If mismatched → regenerate once with a more concrete, less ambiguous rewrite of the same prompt (front-load the subject even more explicitly); do not silently accept a mismatched clip.
2. **Anchor fidelity check:** for CHAINED subjects (§1.1), compare the rendered look against the reference scene. If drifted beyond recognition → regenerate using the frame-chaining fallback (§1.2/§1.3) rather than accepting the mismatch.
3. **Duration check:** confirm actual rendered duration against the §2 estimate; if off by more than ~1s, note the delta in `edit_notes` so the editor can adjust the cut point rather than trimming into the middle of an action.
4. **Failure ceiling:** same as other Gates — max 2 regeneration attempts per clip. If still failing after 2 retries, log the specific clip/scene, fall back to the closest acceptable alternative (e.g., cutaway per §1.3), and note it in `edit_notes` rather than blocking the whole export.