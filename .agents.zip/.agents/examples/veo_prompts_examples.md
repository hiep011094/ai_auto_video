# VEO Prompt Examples — Current Production Standard

Production V9 note: every copyable prompt below begins with the mandatory single-take anchor and ends with the mandatory no-internal-edit Negative lock.

These examples are **copy-structure references**, not generic text to reuse. Each one follows the current production contract in `06_veo_prompt_guide.md`: English only, visual only, one continuous shot, Semantic Lock, useful detail, 900–4,000 total characters with at least 800 positive visual characters before `Negative:`, exact global film-look anchor once, concrete lens/focus/camera/lighting direction, one dominant micro-action with a clear end-frame state, and the complete visual-bible Negative list.

For these examples, the exact global `film_look` anchor from `visual_bible_example_space.json` is:

`cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes`

Do **not** copy that anchor into another project unless it is exactly that project's own `visual_style.film_look`.

---

## Example 1 — Opening establishing shot / part 1 of a sentence

**Purpose:** establish scale without revealing later explanatory details.

```text
Create exactly one uninterrupted continuous shot in one visual setup for the entire clip. Extreme-wide eye-level orbital establishing shot of deep space near the event horizon, Vast cosmic void dominated by a massive black hole at center frame, swirling accretion disk glowing in fiery orange and deep red gradients, stars distorted by gravitational lensing around the edge, pitch-black event horizon absorbing all light in the center, distant galaxies faintly visible in the far background. The camera performs one very slow axial dolly-in from a stable centered composition, keeping the event horizon fixed while the distorted star arcs expand subtly at the frame edges; the accretion flow rotates continuously in one physically coherent direction and faint particulate plasma follows the same orbital motion. Use a 24mm wide-angle lens with deep focus so the luminous disk, warped star field, and distant galaxies remain spatially legible. Motivated illumination comes only from the hot accretion material and distant starlight, producing restrained orange rim light along nearby plasma and preserving true black at the center. Maintain realistic scale, gravitational geometry, and optical falloff; no new object enters the frame. The shot ends slightly closer to the event horizon with the same centered axis, setting up a tighter second part without changing location or visual claim. cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes. Cool blue-black grading across the void with controlled fiery orange-red highlights, natural optical contrast, no exaggerated neon. Negative: watermark, text overlay, burned-in subtitles, logo, cartoonish CGI, obvious fake-looking effects, animated style, flat 2D illustration, lens flare artifacts, overly bright neon colors, no real identifiable people, no celebrity likeness, no graphic violence, no gore, no nudity, no sexual content, no hate symbols, internal cuts, scene transitions, fades, dissolves, morph transitions, montage, time jumps, location changes, visual-domain changes
```

---

## Example 2 — Same sentence, part 2 / visual progression rather than repetition

**Purpose:** move from overall scale to the mechanism currently being narrated.

```text
Create exactly one uninterrupted continuous shot in one visual setup for the entire clip. Medium-close orbital tracking shot aligned almost tangent to the inner accretion flow, using the same deep-space environment and the same black-hole geometry established in the previous scene. The camera glides laterally at a constant distance while turbulent bands of superheated plasma sweep across the foreground and curve toward the dark boundary, making the current scientific claim about matter approaching the event horizon visually explicit rather than repeating the previous wide composition. Use a 50mm lens with shallow depth of field: the nearest plasma filaments remain sharply resolved while the distorted background stars soften into curved luminous streaks. The orange-white plasma provides the motivated key light, casting subtle reflected glow across neighboring gas streams; darker crimson material recedes toward the center with physically plausible orbital direction and no random reversal. Preserve the previous scene's screen direction and warm-to-cool color relationship. The camera movement remains one uninterrupted tracking motion, no second setup appears, and the frame ends with a single bright plasma filament crossing the lower-right foreground just before it reaches the visually dark boundary, creating a precise handoff for the final part. cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes. Controlled fiery orange-red grade around the disk against cool blue-black space, realistic bloom only around the hottest material, natural shadow and exposure rolloff. Negative: watermark, text overlay, burned-in subtitles, logo, cartoonish CGI, obvious fake-looking effects, animated style, flat 2D illustration, lens flare artifacts, overly bright neon colors, no real identifiable people, no celebrity likeness, no graphic violence, no gore, no nudity, no sexual content, no hate symbols, internal cuts, scene transitions, fades, dissolves, morph transitions, montage, time jumps, location changes, visual-domain changes
```

---

## Example 3 — Final part / close scientific detail

**Purpose:** deliver the sentence payoff while remaining in the same physical event.

```text
Create exactly one uninterrupted continuous shot in one visual setup for the entire clip. Extreme close-up insert of one turbulent plasma filament at the inner edge of the accretion disk as it is stretched into a thin luminous arc by the black hole's extreme gravitational environment. The camera is locked to a gentle stabilized orbital drift so the filament remains the dominant subject throughout the uninterrupted take; background stars appear only as soft warped arcs and never become a second subject. Use an 85mm lens with very shallow depth of field and precise sharp focus on the glowing filament texture, revealing granular turbulence, density variation, and a gradual reduction of visible structure toward the dark boundary. Illumination is entirely motivated by the plasma itself, with intense warm highlights rolling naturally into deep crimson and finally black; surrounding space remains underexposed without artificial fill. The physical motion must remain continuous with the previous scene: the filament travels in the same screen direction, its curvature tightens gradually, and no object teleports or reverses. The shot ends with the filament occupying the edge of the dark central region while still visibly outside it, preserving scientific uncertainty rather than inventing an impossible view beyond the boundary. cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes. Restrained orange-red highlight grade, realistic optical bloom, controlled micro-contrast, no fantasy glow. Negative: watermark, text overlay, burned-in subtitles, logo, cartoonish CGI, obvious fake-looking effects, animated style, flat 2D illustration, lens flare artifacts, overly bright neon colors, no real identifiable people, no celebrity likeness, no graphic violence, no gore, no nudity, no sexual content, no hate symbols, internal cuts, scene transitions, fades, dissolves, morph transitions, montage, time jumps, location changes, visual-domain changes
```

---

## Example 4 — Recurring observatory location / human element without identity drift

**Purpose:** show scientific analysis in a consistent recurring environment without relying on readable generated text.

```text
Create exactly one uninterrupted continuous shot in one visual setup for the entire clip. Medium over-the-shoulder shot inside the observatory control room, Modern astronomical observatory interior, dark room lit by blue-tinted monitor glow, large curved displays showing telescope data and star maps, professional equipment racks with blinking indicator LEDs, wide observation windows revealing night sky, minimal overhead lighting creating dramatic shadows. An anonymous generic astronomer is seen only from behind in three-quarter silhouette, seated at the same central workstation and using one hand to adjust a physical control dial while the other remains beside the keyboard; no recognizable real-person likeness is requested. The curved displays show clean unlabeled spectral shapes, star-field points, and abstract measurement traces rather than exact readable words or numbers. The camera performs a slow 35mm dolly-in from shoulder height with shallow depth of field, keeping the scientist's hand and nearest data shape sharp while the far equipment racks fall into soft bokeh. Cool practical monitor light is the motivated key, with a faint warm rim from a low desk lamp and stable shadow direction. Indicator LEDs blink naturally without becoming distracting. The shot ends with the hand resting on the dial and one unlabeled spectral curve centered on the monitor, giving the next scene a clear insert target. cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes. Observatory-specific cool blue grading with restrained warm practical accents and realistic skin-neutral shadow tones. Negative: watermark, text overlay, burned-in subtitles, logo, cartoonish CGI, obvious fake-looking effects, animated style, flat 2D illustration, lens flare artifacts, overly bright neon colors, no real identifiable people, no celebrity likeness, no graphic violence, no gore, no nudity, no sexual content, no hate symbols, internal cuts, scene transitions, fades, dissolves, morph transitions, montage, time jumps, location changes, visual-domain changes
```

---

## Example 5 — Hypothesis / conceptual visualization with correct epistemic status

**Purpose:** visualize a possible scientific model without presenting it as confirmed fact.

```text
Create exactly one uninterrupted continuous shot in one visual setup for the entire clip. Wide conceptual scientific visualization of a possible compact-object model suspended against a restrained deep-space background, explicitly treated as a hypothetical simulation rather than observed footage. A dark spherical region remains centered while thin semi-transparent gravitational field contours bend smoothly around it and a sparse set of test-particle paths curve according to the modeled geometry; no invented organism, civilization, or unverified event is shown. The camera makes one slow 35mm arc of roughly fifteen degrees around the model while keeping the central object at constant scale, allowing the viewer to perceive the three-dimensional curvature without changing setup. Use deep focus so the central model and the nearest trajectory lines remain readable as shapes without relying on labels or equations. Soft cool model illumination defines geometry from camera-left, with a faint rim from the opposite side and physically consistent shadowless visualization lighting appropriate to a scientific simulation. Particle paths move continuously along their curves at measured speed and never jump between trajectories. The shot ends with the camera slightly offset from its starting angle and one trajectory visibly bending behind the central region, creating a clean visual handoff to evidence or limitations in the next scene. cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes. Cool blue-black scientific grade with subtle white-blue model lines, restrained brightness, no holographic neon excess. Negative: watermark, text overlay, burned-in subtitles, logo, cartoonish CGI, obvious fake-looking effects, animated style, flat 2D illustration, lens flare artifacts, overly bright neon colors, no real identifiable people, no celebrity likeness, no graphic violence, no gore, no nudity, no sexual content, no hate symbols, internal cuts, scene transitions, fades, dissolves, morph transitions, montage, time jumps, location changes, visual-domain changes
```

---

## Example 6 — Closing shot / cinematic callback with controlled continuity

**Purpose:** resolve the visual arc without repeating the opening prompt verbatim.

```text
Create exactly one uninterrupted continuous shot in one visual setup for the entire clip. Extreme-wide closing shot of the same deep-space region established at the beginning, now viewed from a much greater distance so the black hole and accretion disk occupy a small but unmistakable point near the center of an immense star field. The camera performs one slow 24mm dolly-out on the same principal axis used in the opening, reversing only camera distance while preserving the black hole's orientation, orbital direction, and color identity; this creates an intentional visual callback rather than an unrelated composition. Use deep focus across the entire cosmic field, with faint distant galaxies gradually entering the outer frame as scale expands. The accretion disk continues its established rotation at a physically consistent rate and gravitationally distorted stars remain concentrated only near the compact object. Illumination remains motivated by starlight and the disk, with deep blacks protected and no artificial foreground fill. The motion remains calm and uninterrupted for the entire take within the same visual setup and location. The shot ends at maximum distance with the black hole still visible but visually small against the larger universe, leaving a stable symmetrical frame suitable for the video's final explanatory payoff. cinematic documentary, subtle film grain, high detail, realistic, deep blacks, high contrast in space scenes. Cool blue-black closing grade with a small controlled orange-red accent at the center, natural optical falloff and restrained contrast. Negative: watermark, text overlay, burned-in subtitles, logo, cartoonish CGI, obvious fake-looking effects, animated style, flat 2D illustration, lens flare artifacts, overly bright neon colors, no real identifiable people, no celebrity likeness, no graphic violence, no gore, no nudity, no sexual content, no hate symbols, internal cuts, scene transitions, fades, dissolves, morph transitions, montage, time jumps, location changes, visual-domain changes
```

---

## What these examples demonstrate

1. **Current narration beat first.** The visual claim is specific to the current spoken beat; later explanation is not shown early.
2. **One uninterrupted shot.** Each prompt has one setup and one primary camera behavior; no internal edits.
3. **Micro-action and end-frame state.** Every clip has visible temporal behavior and finishes in a state the next scene can inherit.
4. **Global look consistency.** The exact `film_look` anchor appears once per prompt, while scene-specific grading/lighting varies deliberately.
5. **Useful detail rather than adjective padding.** Materials, geometry, light source, movement direction, scale, focus and continuity are concrete.
6. **Hypotheses remain hypotheses.** Conceptual scenes do not turn uncertain ideas into confirmed reality.
7. **No exact generated typography.** Scientific screens/graphics are unlabeled; exact text, formulas and numbers should be added during editing.
8. **No audio wording.** Prompts direct only visual generation.


## Continuity-ref companion format

For scene 1 use exactly `opening`. For every later scene, pair the prompt with a handoff string such as:

`Previous end: the black hole remains centered, the bright plasma filament crosses the lower-right foreground, and orbital motion continues clockwise. Current opening: a tighter tangent view begins on that same filament at the same screen direction and warm key-light relationship. Editorial relationship: continuous action.`

For a documentary concept/location change, write two endpoints rather than asking the clip to perform the transition:

`Previous end: the desert aerial ends with the circular ridge centered under late-afternoon sun. Current opening: a geological cross-section simulation begins already centered on the same circular structure, using the same left-to-right light cue. Editorial relationship: matched conceptual cut.`
