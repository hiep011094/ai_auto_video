# Examples Directory

This folder contains real-world examples to help understand the `.agents` documentation and see what good output looks like.

## Files in this directory

### 1. `visual_bible_example_space.json`
A legacy example `visual_bible.json` for reference. Current videos use Buddhist themes (Vietnamese, contemplative voice style).

**Shows:**
- Properly structured characters (including off-screen narrator)
- Multiple locations (deep space + observatory)
- Key objects (Hubble Space Telescope)
- Aspect ratio for SHORT video (9:16 vertical)
- Lighting timeline across video stages
- Comprehensive negative keywords

**Use this as:**
- Reference when creating your first visual_bible.json
- Template for Buddhist themed videos (adapt characters/locations to monks, temples, nature)
- Example of how much detail is needed for visual consistency

---

### 2. `veo_prompts_examples.md`
6 current production-standard `veo_prompt` examples covering all major shot types and scenarios.

**Includes examples of:**
- Opening establishing shot (temple/nature theme)
- Medium shot continuation (same sentence)
- Close-up final part (sentence closer)
- Temple/meditation interior (human element)
- Tracking shot through nature
- Same-sentence visual progression
- Contemplative scene with monk/practitioner
- Reflective visualization with correct certainty
- Closing cinematic callback

**Each example shows:**
- Context (part, shot_type, context_ref)
- Full veo_prompt text
- Why that shot_type was chosen
- How continuity_ref connects to previous scene

**Common patterns documented:**
- What to always include in every prompt
- How to maintain continuity
- How to avoid internal transitions
- Realistic documentary feel techniques
- Part-based shot selection logic

---

## How to use these examples

### For CLI agents:
```bash
# Read examples before writing your first veo_prompts
cat .agents/examples/veo_prompts_examples.md

# Copy and adapt visual_bible structure
cp .agents/examples/visual_bible_example_space.json \
   data/video_short/your-topic/visual_bible.json

# Edit to match your specific topic, but keep the structure
```

### For understanding the system:
1. Read `.agents/05_visual_bible_guide.md` first (theory)
2. Then read `visual_bible_example_space.json` (practice)
3. Read `.agents/06_veo_prompt_guide.md` (theory)
4. Then read `veo_prompts_examples.md` (practice)

### For quality checking:
- Compare your visual_bible.json structure to the example
- Check if your veo_prompts follow the patterns shown
- Verify you're including all required elements (negative keywords, camera style, lighting, etc.)

---

## Adding more examples

If you create videos that work particularly well, consider adding their visual_bible.json and sample veo_prompts here as additional examples for:
- Different themes (meditation, history, temples, nature, etc.)
- LONG video examples (multi-chapter)
- Different lighting scenarios (dawn temple scenes, candlelit meditation, mountain mist, etc.)

**Naming convention:**
- `visual_bible_example_[theme].json`
- `veo_prompts_example_[theme].md`

Where `[theme]` could be: meditation, temple, history, jataka, dharma, etc.
